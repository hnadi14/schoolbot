# schoolbot/services/score_service.py
import numpy as np
from typing import List, Tuple, Dict, Optional
import math
import tempfile

import pandas as pd
import arabic_reshaper
from bidi.algorithm import get_display
import matplotlib.pyplot as plt
from matplotlib import rcParams

from schoolbot.database.data_loader import get_connection

# تنظیم فونت برای فارسی
rcParams["font.family"] = "Tahoma"


def get_school_id_by_student(student_id: int) -> Optional[int]:
    """
    گرفتن school_id مربوط به یک دانش‌آموز
    ورودی: student_id
    خروجی: school_id یا None
    """
    query = """
        SELECT g.school_id
        FROM students s
        JOIN classes c ON s.class_id = c.id
        JOIN grades g ON c.grade_id = g.id
        WHERE s.id = ?
    """
    with get_connection() as conn:
        cur = conn.cursor()
        row = cur.execute(query, (student_id,)).fetchone()
    return row[0] if row else None


def get_report_periods(school_id: int) -> List[Tuple[int, str]]:
    """
    دریافت لیست دوره‌های کارنامه برای یک مدرسه مشخص
    ورودی: school_id
    خروجی: [(id, name), ...]
    """
    query = """
        SELECT id, name 
        FROM report_periods 
        WHERE approved = 1 AND school_id = ?
        ORDER BY id DESC
    """
    with get_connection() as conn:
        cur = conn.cursor()
        periods = cur.execute(query, (school_id,)).fetchall()
    return periods


def get_teacher_school_id(teacher_id: int) -> Optional[int]:
    """
    گرفتن school_id یک معلم بر اساس id
    بازگرداندن None اگر معلم پیدا نشود
    """
    query = "SELECT school_id FROM teachers WHERE id = ?"
    with get_connection() as conn:
        cur = conn.cursor()
        row = cur.execute(query, (teacher_id,)).fetchone()
    return row[0] if row else None


def get_report_periods_teachers(school_id: int) -> List[Tuple[int, str]]:
    """
    دریافت لیست دوره‌های کارنامه (نسخه‌ی معلم‌ها)
    خروجی: [(id, name), ...]
    """
    query = "SELECT id, name FROM report_periods where school_id=? ORDER BY id DESC"
    with get_connection() as conn:
        cur = conn.cursor()
        periods = cur.execute(query, (school_id,)).fetchall()
    return periods


def get_student_scores(student_id: int, report_period_id: int) -> List[
    Tuple[str, Optional[float], Optional[str], Optional[int]]]:
    """
    دریافت لیست نمرات دانش‌آموز برای یک دوره
    خروجی: [(subject_name, score, description, coefficient), ...]
    """
    query = """
        SELECT s.name, sc.score, sc.description, s.coefficient
        FROM scores sc
        JOIN subjects s ON sc.subject_id = s.id
        WHERE sc.student_id = ? AND sc.report_period_id = ?
        ORDER BY s.name
    """
    with get_connection() as conn:
        cur = conn.cursor()
        scores = cur.execute(query, (student_id, report_period_id)).fetchall()
    return scores


def calculate_weighted_average(scores: List[Tuple[str, Optional[float], Optional[str], Optional[int]]]) -> Optional[
    float]:
    """
    محاسبه معدل وزنی بر اساس ضریب درس‌ها
    ورودی: لیست [(subject_name, score, description, coefficient), ...]
    خروجی: معدل یا None اگر نمره‌ای نبود
    """
    total_weighted = 0.0
    total_coeff = 0

    for subj_name, score, desc, coeff in scores:
        if score is not None and coeff is not None:
            total_weighted += float(score) * int(coeff)
            total_coeff += int(coeff)

    if total_coeff == 0:
        return None

    return round(total_weighted / total_coeff, 2)


def get_class_average_scores(student_id: int, report_period_id: int) -> List[Tuple[str, float, Optional[int]]]:
    """
    بازگرداندن میانگین نمرات هر درس برای کلاس دانش‌آموز.
    خروجی: [(subject_name, average_score, coefficient), ...]
    """
    with get_connection() as conn:
        cur = conn.cursor()
        # ابتدا کلاس دانش‌آموز را پیدا می‌کنیم
        cur.execute("SELECT class_id FROM students WHERE id = ?", (student_id,))
        result = cur.fetchone()
        if not result:
            return []
        class_id = result[0]

        # میانگین هر درس در کلاس برای دوره مشخص
        cur.execute("""
            SELECT s.name, AVG(sc.score) as avg_score, s.coefficient
            FROM scores sc
            JOIN subjects s ON sc.subject_id = s.id
            JOIN students st ON sc.student_id = st.id
            WHERE st.class_id = ? AND sc.report_period_id = ?
            GROUP BY s.name, s.coefficient
            ORDER BY s.name
        """, (class_id, report_period_id))
        averages = cur.fetchall()

    # تبدیل میانگین‌ها به float
    return [(row[0], float(row[1]), row[2]) for row in averages]


def get_student_class(student_id: int) -> Tuple[Optional[int], Optional[int]]:
    """
    دریافت شناسه کلاس و پایه دانش‌آموز
    خروجی: class_id, grade_id
    """
    with get_connection() as conn:
        cur = conn.cursor()

        # گرفتن class_id از students
        cur.execute("SELECT class_id FROM students WHERE id = ?", (student_id,))
        result = cur.fetchone()
        if not result:
            return None, None
        class_id = result[0]

        # گرفتن grade_id از classes
        cur.execute("SELECT grade_id FROM classes WHERE id = ?", (class_id,))
        result = cur.fetchone()
        grade_id = result[0] if result else None

    return class_id, grade_id


def get_school_multi_period_analysis(school_id: int) -> Dict:
    """
    تحلیل جامع تمام دوره‌های یک مدرسه (به ترتیب زمانی)
    خروجی: dict شامل آمار هر دوره و مقایسه کلی اول تا آخر
    """
    # همه‌ی دوره‌های مدرسه
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute("""
            SELECT id, name FROM report_periods
            WHERE school_id = ?
            ORDER BY id ASC
        """, (school_id,))
        periods = cur.fetchall()

    if not periods:
        return {"message": "⚠️ هیچ دوره‌ای برای این مدرسه وجود ندارد."}

    results: Dict[str, Dict] = {}

    # تعداد کل دانش‌آموزان مدرسه
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute("""
            SELECT COUNT(*) FROM students
            WHERE class_id IN (
                SELECT id FROM classes WHERE grade_id IN (
                    SELECT id FROM grades WHERE school_id=?
                )
            )
        """, (school_id,))
        total_students = cur.fetchone()[0]

    # تحلیل هر دوره (همان منطق قبلی حفظ شده)
    for pid, pname in periods:
        with get_connection() as conn:
            cur = conn.cursor()
            cur.execute("""
                SELECT sc.student_id,
                       ROUND(SUM(sc.score * s.coefficient) * 1.0 / SUM(s.coefficient), 2) as avg_score
                FROM scores sc
                JOIN subjects s ON sc.subject_id = s.id
                JOIN students st ON sc.student_id = st.id
                JOIN classes c ON st.class_id = c.id
                WHERE sc.report_period_id = ? 
                  AND c.grade_id IN (SELECT id FROM grades WHERE school_id = ?)
                GROUP BY sc.student_id
            """, (pid, school_id))
            student_averages = cur.fetchall()

            if not student_averages:
                results[pname] = {"message": "⚠️ هیچ نمره‌ای ثبت نشده است."}
                continue

            averages = [row[1] for row in student_averages]

            # محاسبات آماری
            count_with_scores = len(averages)
            overall_avg = round(sum(averages) / count_with_scores, 2)

            below_10 = len([a for a in averages if a < 10])
            above_10 = count_with_scores - below_10

            min_avg = min(averages)
            max_avg = max(averages)

            ranges = {
                "0-5": len([a for a in averages if 0 <= a < 5]),
                "5-10": len([a for a in averages if 5 <= a < 10]),
                "10-15": len([a for a in averages if 10 <= a < 15]),
                "15-20": len([a for a in averages if 15 <= a <= 20]),
            }

            # میانگین و تعداد نمرات هر درس
            cur.execute("""
                SELECT s.name, COUNT(sc.score) as count_scores, ROUND(AVG(sc.score),2) as avg_sub
                FROM scores sc
                JOIN subjects s ON sc.subject_id = s.id
                JOIN students st ON sc.student_id = st.id
                JOIN classes c ON st.class_id = c.id
                WHERE sc.report_period_id = ? 
                  AND c.grade_id IN (SELECT id FROM grades WHERE school_id = ?)
                GROUP BY s.name
                ORDER BY avg_sub
            """, (pid, school_id))
            subject_stats = cur.fetchall()

        # تبدیل به دیکشنری {درس: {تعداد، میانگین}}
        subjects_info = {
            s: {"count": cnt, "avg": avg}
            for s, cnt, avg in subject_stats
        }

        weak_subjects = [s for s, data in subjects_info.items() if data["avg"] < 12]
        strong_subjects = [s for s, data in subjects_info.items() if data["avg"] >= 15]

        results[pname] = {
            "total_students": total_students,
            "count_with_scores": count_with_scores,
            "overall_avg": overall_avg,
            "below_10": below_10,
            "above_10": above_10,
            "min_avg": min_avg,
            "max_avg": max_avg,
            "ranges": ranges,
            "weak_subjects": weak_subjects,
            "strong_subjects": strong_subjects,
            "subjects": subjects_info,
        }

    # ------------------ مقایسه دوره‌ها با قبلی ------------------
    comparisons: List[Dict] = []

    period_names = list(results.keys())
    for i in range(1, len(period_names)):
        prev_name = period_names[i - 1]
        curr_name = period_names[i]

        prev_stats = results[prev_name]
        curr_stats = results[curr_name]

        comp: Dict[str, Optional[float]] = {
            "prev_period": prev_name,
            "curr_period": curr_name
        }

        if "overall_avg" in prev_stats and "overall_avg" in curr_stats:
            comp["avg_change"] = round(curr_stats["overall_avg"] - prev_stats["overall_avg"], 2)

        if "above_10" in prev_stats and "above_10" in curr_stats:
            comp["success_change"] = curr_stats["above_10"] - prev_stats["above_10"]

        comparisons.append(comp)

    return {
        "periods": results,
        "comparisons": comparisons
    }


def get_student_rank(student_id: int, report_period_id: int) -> Tuple[
    Optional[int], Optional[int], Optional[int], Dict[str, List[Dict]]]:
    """
    دریافت رتبه دانش‌آموز در کلاس، پایه و مدرسه
    خروجی: (rank_class, rank_grade, rank_school)
    نکته: رتبه بر اساس دانش‌آموزانی محاسبه می‌شود که در آن دوره نمره دارند.
    """
    with get_connection() as conn:
        cur = conn.cursor()

        # گرفتن کلاس و پایه دانش‌آموز
        class_id, grade_id = get_student_class(student_id)

        if class_id is None or grade_id is None:
            return None, None, None

        # رتبه در کلاس
        cur.execute("""
            SELECT student_id
            FROM (
                SELECT sc.student_id,
                       SUM(sc.score * s.coefficient) / SUM(s.coefficient) AS avg_score
                FROM scores sc
                JOIN subjects s ON sc.subject_id = s.id
                WHERE sc.report_period_id = ? AND sc.student_id IN (
                    SELECT id FROM students WHERE class_id = ?
                )
                GROUP BY sc.student_id
            )
            ORDER BY avg_score DESC
        """, (report_period_id, class_id))
        students_class = [row[0] for row in cur.fetchall()]
        rank_class = students_class.index(student_id) + 1 if student_id in students_class else None

        # رتبه در پایه
        cur.execute("""
            SELECT student_id
            FROM (
                SELECT sc.student_id,
                       SUM(sc.score * s.coefficient) / SUM(s.coefficient) AS avg_score
                FROM scores sc
                JOIN subjects s ON sc.subject_id = s.id
                WHERE sc.report_period_id = ? AND sc.student_id IN (
                    SELECT id FROM students WHERE class_id IN (
                        SELECT id FROM classes WHERE grade_id = ?
                    )
                )
                GROUP BY sc.student_id
            )
            ORDER BY avg_score DESC
        """, (report_period_id, grade_id))
        students_grade = [row[0] for row in cur.fetchall()]
        rank_grade = students_grade.index(student_id) + 1 if student_id in students_grade else None

        # رتبه در مدرسه
        cur.execute("""
            SELECT student_id
            FROM (
                SELECT sc.student_id,
                       SUM(sc.score * s.coefficient) / SUM(s.coefficient) AS avg_score
                FROM scores sc
                JOIN subjects s ON sc.subject_id = s.id
                WHERE sc.report_period_id = ?
                GROUP BY sc.student_id
            )
            ORDER BY avg_score DESC
        """, (report_period_id,))
        students_school = [row[0] for row in cur.fetchall()]
        rank_school = students_school.index(student_id) + 1 if student_id in students_school else None

        # گرفتن نفرات برتر با تابع جداگانه
    top_students = {
        "class": get_top_students(report_period_id, "class", class_id, 3),
        "grade": get_top_students(report_period_id, "grade", grade_id, 3),
        "school": get_top_students(report_period_id, "school", None, 3),
    }
    return rank_class, rank_grade, rank_school, top_students


def get_top_students(report_period_id: int, scope: str, scope_id: Optional[int] = None, top_n: int = 3) -> List[Dict]:
    """
    دریافت نفرات برتر بر اساس محدوده:
    scope = "class"  → بر اساس کلاس (نیاز به class_id)
    scope = "grade"  → بر اساس پایه (نیاز به grade_id)
    scope = "school" → کل مدرسه (نیازی به scope_id ندارد)
    خروجی: [ {id, name, class, avg}, ... ]
    """
    with get_connection() as conn:
        cur = conn.cursor()

        base_query = """
            SELECT st.id, st.name, c.name,
                   ROUND(SUM(sc.score * s.coefficient) / SUM(s.coefficient), 2) AS avg_score
            FROM scores sc
            JOIN subjects s ON sc.subject_id = s.id
            JOIN students st ON st.id = sc.student_id
            JOIN classes c ON st.class_id = c.id
            WHERE sc.report_period_id = ?
        """

        params = [report_period_id]

        if scope == "class" and scope_id:
            base_query += " AND st.class_id = ?"
            params.append(scope_id)
        elif scope == "grade" and scope_id:
            base_query += " AND st.class_id IN (SELECT id FROM classes WHERE grade_id = ?)"
            params.append(scope_id)

        base_query += """
            GROUP BY st.id
            ORDER BY avg_score DESC
            LIMIT ?
        """
        params.append(top_n)

        cur.execute(base_query, tuple(params))
        rows = cur.fetchall()

    return [{"id": r[0], "name": r[1], "class": r[2], "avg": r[3]} for r in rows]


def get_rank_context_counts(student_id: int, report_period_id: int) -> Tuple[
    Optional[int], Optional[int], Optional[int]]:
    """
    ✅ تابع کمکی جدید:
    تعداد دانش‌آموزانی که در «کلاس/پایه/مدرسه» در آن دوره نمره دارند را برمی‌گرداند
    تا بتوانیم بنویسیم «رتبه X از N».
    خروجی: (count_class, count_grade, count_school)
    """
    class_id, grade_id = get_student_class(student_id)
    if class_id is None or grade_id is None:
        return None, None, None

    with get_connection() as conn:
        cur = conn.cursor()

        # تعداد در کلاس (کسانی که در آن دوره نمره ثبت شده دارند)
        cur.execute("""
            SELECT COUNT(DISTINCT sc.student_id)
            FROM scores sc
            JOIN students st ON sc.student_id = st.id
            WHERE sc.report_period_id = ? AND st.class_id = ?
        """, (report_period_id, class_id))
        count_class = cur.fetchone()[0] or 0

        # تعداد در پایه
        cur.execute("""
            SELECT COUNT(DISTINCT sc.student_id)
            FROM scores sc
            JOIN students st ON sc.student_id = st.id
            JOIN classes c ON st.class_id = c.id
            WHERE sc.report_period_id = ? AND c.grade_id = ?
        """, (report_period_id, grade_id))
        count_grade = cur.fetchone()[0] or 0

        # تعداد در مدرسه
        cur.execute("""
            SELECT COUNT(DISTINCT sc.student_id)
            FROM scores sc
            WHERE sc.report_period_id = ?
        """, (report_period_id,))
        count_school = cur.fetchone()[0] or 0

    return count_class, count_grade, count_school


# def get_student_all_scores(student_id: int) -> List[Tuple[str, str, Optional[float], Optional[str]]]:
#     """
#     برگرداندن تاریخچه‌ی همه‌ی نمرات دانش‌آموز مربوط به دوره‌های تأیید شده
#     خروجی: [(subject_name, period_name, score, description), ...]
#     """
#     query = """
#         SELECT s.name, rp.name, sc.score, sc.description, s.coefficient
#         FROM scores sc
#         JOIN subjects s ON sc.subject_id = s.id
#         JOIN report_periods rp ON sc.report_period_id = rp.id
#         WHERE sc.student_id = ? AND rp.approved = 1
#         ORDER BY s.name, rp.id
#     """
#     with get_connection() as conn:
#         cur = conn.cursor()
#         results = cur.execute(query, (student_id,)).fetchall()
#     return results
#
# from typing import List, Tuple, Optional

def get_student_all_scores(student_id: int) -> List[
    Tuple[str, str, Optional[float], Optional[str], Optional[float], Optional[float], Optional[str]]]:
    """
    برگرداندن تاریخچه‌ی همه‌ی نمرات دانش‌آموز مربوط به دوره‌های تأیید شده
    به همراه میانگین نمرات کلاس و نام معلم در آن درس و دوره

    خروجی:
    [(subject_name, period_name, score, description, coefficient, class_average_score, teacher_name), ...]
    """
    query = """
        WITH ClassAverage AS (
            -- Step 1: Calculate the average score for each subject and period for the student's class
            SELECT
                sc_avg.subject_id,
                sc_avg.report_period_id,
                AVG(sc_avg.score) AS average_score
            FROM
                scores sc_avg
            JOIN
                students s_avg ON sc_avg.student_id = s_avg.id
            WHERE
                s_avg.class_id = (SELECT class_id FROM students WHERE id = ?) -- Get class_id for the specific student
            GROUP BY
                sc_avg.subject_id, sc_avg.report_period_id
        )
        -- Step 2: Select the student's scores and join them with the calculated class averages and teacher name
        SELECT
            s.name,                         -- نام درس
            rp.name,                        -- نام دوره
            sc.score,                       -- نمره دانش‌آموز
            sc.description,                 -- توضیحات نمره
            s.coefficient,                  -- ضریب درس
            ca.average_score,               -- میانگین نمره کلاس
            t.name AS teacher_name          -- جدید: نام معلم
        FROM
            scores sc
        JOIN
            subjects s ON sc.subject_id = s.id
        JOIN
            report_periods rp ON sc.report_period_id = rp.id
        LEFT JOIN
            teachers t ON s.teacher_id = t.id -- جدید: اتصال به جدول معلمان
        LEFT JOIN
            ClassAverage ca ON sc.subject_id = ca.subject_id AND sc.report_period_id = ca.report_period_id
        WHERE
            sc.student_id = ? AND rp.approved = 1
        ORDER BY
            s.name, rp.id;
    """
    with get_connection() as conn:
        cur = conn.cursor()
        # The student_id parameter is needed twice in the query
        results = cur.execute(query, (student_id, student_id)).fetchall()
    return results


def get_class_averages_for_all_periods(student_id: int) -> Dict[str, float]:
    """
    معدل وزنی کل کلاس را برای هر دوره تحصیلی تایید شده محاسبه می‌کند.
    این عملیات تنها با یک کوئری بهینه به دیتابیس انجام می‌شود.

    خروجی:
        یک دیکشنری شامل (نام دوره: معدل کلاس)
        Example: {'مهر ماه': 17.85, 'آبان ماه': 18.12}
    """
    # این کوئری تمام منطق را در دیتابیس اجرا می‌کند
    query = """
        SELECT
            rp.name AS period_name,
            -- محاسبه معدل وزنی: مجموع (نمره * ضریب) تقسیم بر مجموع ضرایب
            SUM(sc.score * s.coefficient) / SUM(s.coefficient) AS class_average
        FROM
            scores sc
        JOIN
            subjects s ON sc.subject_id = s.id
        JOIN
            report_periods rp ON sc.report_period_id = rp.id
        JOIN
            students st ON sc.student_id = st.id
        WHERE
            -- شرط اصلی: دانش‌آموز باید در همان کلاس دانش‌آموز ورودی باشد
            st.class_id = (SELECT class_id FROM students WHERE id = ?)
            AND rp.approved = 1
            AND sc.score IS NOT NULL  -- نمرات خالی در معدل لحاظ نمی‌شوند
        GROUP BY
            rp.id, rp.name  -- گروه‌بندی نتایج بر اساس هر دوره
        ORDER BY
            rp.id;          -- مرتب‌سازی دوره‌ها به ترتیب زمانی
    """
    with get_connection() as conn:
        cur = conn.cursor()
        # student_id به عنوان پارامتر به ساب‌کوئری پاس داده می‌شود
        results = cur.execute(query, (student_id,)).fetchall()

    # تبدیل لیست تاپل‌های خروجی به یک دیکشنری خوانا
    # مثال خروجی results: [('مهر ماه', 17.853), ('آبان ماه', 18.121)]
    class_averages = {period_name: round(avg, 2) for period_name, avg in results}

    return class_averages


import math
import tempfile
from typing import List, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import arabic_reshaper
from bidi.algorithm import get_display
from adjustText import adjust_text  # جدید: ایمپورت کتابخانه


def generate_multi_subject_charts(all_scores: List[Tuple], name: str = "") -> List[str]:
    """
    نسخه نهایی و حرفه‌ای برای ترسیم نمودارها با قابلیت‌های تحلیلی و جلوگیری از همپوشانی متن.
    """

    def fix_farsi(text: str) -> str:
        return get_display(arabic_reshaper.reshape(str(text)))

    # --- تعریف ثابت‌ها برای رنگ‌ها و استایل ---

    SUBJECT_COLORS = [
        'orange','deepskyblue','purple','blue'
    ]
    AVERAGE_COLOR = 'grey'
    POSITIVE_FILL_COLOR = 'mediumseagreen'
    NEGATIVE_FILL_COLOR = 'lightcoral'

    df = pd.DataFrame(
        all_scores,
        columns=["subject", "period_name", "score", "desc", "coefficient", "average_score","teacher_name"]
    )
    df['score'] = pd.to_numeric(df['score'], errors='coerce')
    df['average_score'] = pd.to_numeric(df['average_score'], errors='coerce')
    df.dropna(subset=['score', 'average_score'], inplace=True)

    if df.empty:
        return []

    df["period_name"] = df["period_name"].apply(fix_farsi)
    subjects = list(df["subject"].unique())
    group_size = 4
    n_groups = math.ceil(len(subjects) / group_size)
    chart_files: List[str] = []

    for g in range(n_groups):
        start = g * group_size
        end = start + group_size
        group_subjects = subjects[start:end]

        fig, axes = plt.subplots(2, 2, figsize=(16, 11), sharey=True)
        axes = np.ravel(axes)

        for i, subj in enumerate(group_subjects):
            ax = axes[i]

            subj_data = df[df["subject"] == subj]
            student_scores = subj_data["score"]
            average_scores = subj_data["average_score"]
            periods = subj_data["period_name"]

            subject_color = SUBJECT_COLORS[i % len(SUBJECT_COLORS)]

            # رسم خطوط اصلی
            ax.plot(periods, student_scores, color=subject_color, marker='o', linewidth=2.5,
                    label=fix_farsi("نمره دانش‌آموز"), zorder=10)
            ax.plot(periods, average_scores, color=AVERAGE_COLOR, marker='x', linestyle='--',
                    label=fix_farsi("میانگین کلاس"), zorder=5)

            # رنگ کردن ناحیه بین دو نمودار
            ax.fill_between(periods, student_scores, average_scores, where=(student_scores >= average_scores),
                            color=POSITIVE_FILL_COLOR, alpha=0.3, interpolate=True)
            ax.fill_between(periods, student_scores, average_scores, where=(student_scores < average_scores),
                            color=NEGATIVE_FILL_COLOR, alpha=0.3, interpolate=True)

            # --- جدید: آماده‌سازی متن‌ها برای adjust_text ---
            texts = []
            bbox_props = dict(boxstyle="round,pad=0.2", facecolor='white', alpha=0.7, edgecolor='none')

            # افزودن متن نمرات دانش‌آموز به لیست
            for x, y in zip(periods, student_scores):
                texts.append(ax.text(x, y, f"{y:.1f}", ha='right', va='top',
                                     fontsize=10,fontweight="bold", color=subject_color, bbox=bbox_props, zorder=20))

            # افزودن متن میانگin کلاس به لیست
            for x, y in zip(periods, average_scores):
                texts.append(ax.text(x, y, f"{y:.1f}", ha='left', va='bottom',
                                     fontsize=8,fontweight="bold", color=AVERAGE_COLOR, bbox=bbox_props, zorder=20))

            # فراخوانی adjust_text برای جابجایی هوشمند متن‌ها
            adjust_text(texts, ax=ax, arrowprops=dict(arrowstyle='-', color='grey', lw=0.5))

            # تنظیمات ظاهری نمودار
            ax.set_title(fix_farsi(subj), fontsize=14, fontweight="bold")
            ax.grid(axis="y", linestyle="--", alpha=0.7)
            # یک مکان مشخص مانند 'بالا راست' را تعیین کنید
            ax.legend(loc='lower right')
            ax.tick_params(axis='x', rotation=15)
            ax.set_ylim(0, 21)  # کمی فضای بیشتر برای اعداد
            ax.set_yticks([0, 5, 10, 15, 20])

        for i in range(len(group_subjects), len(axes)):
            axes[i].set_visible(False)

        fig.suptitle(fix_farsi(f"تحلیل روند نمرات: {name} (درس های گروه {g + 1})"), fontsize=18, fontweight="bold")
        plt.tight_layout(rect=[0, 0, 1, 0.96])

        tmp_file = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
        plt.savefig(tmp_file.name, bbox_inches="tight", dpi=300)
        plt.close(fig)
        chart_files.append(tmp_file.name)

    return chart_files
