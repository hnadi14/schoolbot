import openai
from openai import OpenAI
import os
import logging

# اتصال امن به API از طریق متغیرهای محیطی
# این روش استاندارد و امن برای مدیریت کلیدهای API است
# هشدار: هرگز کلید را مستقیماً در کد قرار ندهید!
client = OpenAI(
    api_key="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"
)

# تنظیمات اولیه برای لاگ کردن خطاها در کنسول
logging.basicConfig(level=logging.ERROR,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')


def get_chatbot_response(role: str, user_question: str) -> str:
    """
    این تابع یک سوال از کاربر دریافت کرده، آن را به OpenAI ارسال می‌کند
    و خطاهای احتمالی مانند اتمام اعتبار، تایم‌اوت و... را مدیریت و لاگ می‌کند.
    """
    try:
        prompt = ""
        if role == "teacher":
            prompt = f"«فرض کن یک معلم تراز اول و کارکشته هستی لطفاً آمار کلاس زیر را به صورت خیلی کوتاه تحلیل کن و فقط راهکارهای کاربردی بده. خروجی را در دو بخش جداگانه با عنوان های 'تحلیل کلاس' و 'راهکار سریع و کاربردی' بنویس. از مقدمه، نتیجه‌گیری یا جملات اضافی خودداری کن و نهایتاً در 150 کلمه باشه."
        elif role == "manager":
            prompt = f"«فرض کن یک برنامه ریز و مشاور تحصیلی تراز اول و کارکشته هستی لطفاً آمار مدرسه زیر را به صورت خیلی کوتاه تحلیل کن و فقط راهکارهای کاربردی بده. خروجی را در دو بخش جداگانه با عنوان های 'تحلیل مدرسه' و 'راهکار سریع و کاربردی' بنویس. از مقدمه، نتیجه‌گیری یا جملات اضافی خودداری کن و نهایتاً در 150 کلمه باشه."
        else:  # نقش دانش‌آموز
            prompt = f"«فرض کن یک معلم و مشاور تحصیلی تراز اول و کارکشته هستی لطفاً وضعیت دانش اموز زیر را به صورت خیلی کوتاه تحلیل کن و فقط راهکارهای کاربردی بده. در ضمن توضیحات دبیر به دانش اموز رو در هر درس هم مد نظر داشته باش. (فرض کن با خود دانش اموز صحبت می کنی و به صورت محاوره ای صحبت کن) خروجی را در دو بخش جداگانه با عنوان های 'تحلیل کارنامه' و 'راهکار سریع و کاربردی' بنویس. از مقدمه، نتیجه‌گیری یا جملات اضافی خودداری کن و نهایتاً در 150 کلمه باشه."

        # سوال کاربر به پیام اضافه می‌شود
        full_message = prompt + " " + user_question

        # ارسال درخواست به مدل gpt-4o-mini با محدودیت زمانی
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "user", "content": full_message}
            ],
            timeout=10.0
        )

        # استخراج متن پاسخ
        return response.choices[0].message.content

    # 1. مدیریت خطای اتمام اعتبار (مهم‌ترین تغییر)
    except openai.RateLimitError as e:
        logging.error(f"RateLimitError - اعتبار حساب OpenAI تمام شده است: {e}")
        return f"اعتبار حساب OpenAI به پایان رسیده یا سقف استفاده پر شده است: _@_error_@_ {e}"

    # 2. مدیریت خطای تایم‌اوت
    except openai.APITimeoutError as e:
        logging.error(f"APITimeoutError - پاسخی از سرور دریافت نشد: {e}")
        return f"پاسخی از سرور در 5 ثانیه دریافت نشد: _@_error_@_ {e}"

    # 3. مدیریت سایر خطاهای احتمالی از سمت OpenAI (مثلا کلید نامعتبر)
    except openai.APIConnectionError as e:
        logging.error(f"APIConnectionError - خطا در اتصال به سرور OpenAI: {e}")
        return f"خطا در اتصال به سرور OpenAI: _@_error_@_ {e}"

    # 4. مدیریت سایر خطاهای عمومی
    except Exception as e:
        logging.error(f"Unexpected Exception - یک خطای پیش‌بینی نشده رخ داد: {e}", exc_info=True)
        return f"یک خطای پیش‌بینی نشده رخ داد: _@_error_@_ {e}"
