import os
import logging
from collections import Counter

import jdatetime

from schoolbot.services.open_ai_response import get_chatbot_response
from schoolbot.services.score_service import get_report_periods_teachers, get_teacher_school_id
from schoolbot.utils.keyboards import normalize_digits, to_persian_digits
from matplotlib import rcParams
import matplotlib.pyplot as plt
import numpy as np
import tempfile
import logging

from schoolbot.services.report_service import (
    get_subjects_by_teacher,
    get_students_by_class,
    get_student_score,
    save_student_score,
    get_class_by_id, get_students_scores_by_class,
)

# ------------------ Logging: فقط خطاها ------------------
logging.basicConfig(
    level=logging.ERROR,
    format="%(asctime)s - [%(levelname)s] - %(message)s"
)
# کاهش لاگ سطح پایین از کتابخانه‌های خارجی
logging.getLogger("matplotlib").setLevel(logging.WARNING)
logging.getLogger("aiohttp").setLevel(logging.WARNING)
logging.getLogger("balethon").setLevel(logging.WARNING)

teacher_states = {}  # keyed by teacher's DB id (user_id)

# # 🎨 ست کردن فونت پیش‌فرض فارسی (در صورت نصب بودن روی سیستم)
# rcParams['font.family'] = 'Tahoma'  # می‌تونی "Vazir" یا "IRANSans" هم بذاری

# کتابخانه‌های فارسی‌سازی را اینجا import می‌کنیم
try:
    import arabic_reshaper
    from bidi.algorithm import get_display
except ImportError:
    print("WARNING: 'arabic_reshaper' or 'python-bidi' not found. Farsi text will not be displayed correctly.")
    print("Install them using: pip install arabic_reshaper python-bidi")


    # توابع جایگزین تعریف می‌کنیم تا برنامه از کار نیفتد
    def get_display(text):
        return text


    def arabic_reshaper_reshape(text):
        return text
else:
    # اگر ایمپورت موفق بود، تابع اصلی را تعریف می‌کنیم
    def arabic_reshaper_reshape(text):
        return arabic_reshaper.reshape(text)


def generate_class_summary_chart_robust(scores_list, class_name="", subject_name="", name=""):
    """
    نسخه نهایی و پایدار نمودار با مدیریت خطای کامل و بررسی ورودی.
    """
    # 1. بررسی ورودی قبل از شروع هر کاری
    if not scores_list:
        logging.warning("⚠️ لیست نمرات ورودی خالی است. نموداری تولید نشد.")
        return None

    try:
        # تبدیل ورودی به آرایه NumPy برای محاسبات و بررسی نوع داده
        scores = np.array(scores_list, dtype=float)
        if np.isnan(scores).any():  # بررسی وجود مقادیر نامعتبر مانند NaN
            raise ValueError("لیست نمرات حاوی مقادیر غیرعددی یا نامعتبر است.")
    except (ValueError, TypeError) as e:
        logging.error(f"❌ خطای داده ورودی: {e}")
        return None

    fig = None  # متغیر را بیرون از try تعریف می‌کنیم تا در finally قابل دسترس باشد
    try:
        def fix_farsi(text: str) -> str:
            return get_display(arabic_reshaper_reshape(text))

        # plt.rcParams['font.sans-serif'] = ['Vazir', 'Tahoma', 'DejaVu Sans']

        fig, axes = plt.subplots(1, 2, figsize=(16, 7), dpi=300)
        fig.suptitle(fix_farsi(f" تحلیل آماری نمرات {subject_name} {class_name}: {name} --- {jdatetime.datetime.now().strftime(' %d %m %Y')}"), fontsize=18, weight="bold")

        # --- Boxplot ---
        axes[0].boxplot(
            scores, vert=True, patch_artist=True,
            boxprops=dict(facecolor="#90caf9", color="#1e88e5", linewidth=1.5),
            whiskerprops=dict(color="#1e88e5", linewidth=1.2),
            capprops=dict(color="#1e88e5", linewidth=1.2),
            medianprops=dict(color="red", linewidth=2),
            flierprops=dict(marker="o", markersize=0)
        )

        categories = {
            '#ef5350': scores[scores < 10],
            '#ffee58': scores[(scores >= 10) & (scores < 15)],
            '#66bb6a': scores[scores >= 15]
        }

        for color, score_group in categories.items():
            if score_group.size > 0:
                x_jitter = np.random.normal(1, 0.04, size=len(score_group))
                axes[0].plot(x_jitter, score_group, marker='o', linestyle='None', alpha=0.8,
                             color=color, markersize=6, markeredgecolor='black', markeredgewidth=0.5)

        axes[0].set_title(fix_farsi("پراکندگی نمرات"), fontsize=14, weight="bold")
        axes[0].set_ylabel(fix_farsi("نمره"), fontsize=12)
        axes[0].set_facecolor("#f9f9f9")
        axes[0].grid(axis="y", linestyle="--", alpha=0.4)

        stats = {
            "min": np.min(scores), "q1": np.percentile(scores, 25),
            "median": np.median(scores), "q3": np.percentile(scores, 75),
            "max": np.max(scores), "mean": np.mean(scores),
            "std": np.std(scores),
        }

        for key, value in stats.items():
            if key != "std":
                axes[0].text(1.15, value, f"{value:.1f}", va="center", ha="left", fontsize=9,
                             bbox=dict(boxstyle="round,pad=0.3", fc="yellow", alpha=0.6))

        axes[0].axhline(stats["mean"], color="green", linestyle="--", linewidth=1.5, label=fix_farsi("میانگین"))
        axes[0].axhline(stats["mean"] + stats["std"], color="orange", linestyle=":", linewidth=1.2,
                        label=fix_farsi("±σ انحراف معیار"))
        axes[0].axhline(stats["mean"] - stats["std"], color="orange", linestyle=":", linewidth=1.2)
        axes[0].plot(1, stats["min"], marker="*", color="red", markersize=12, label=fix_farsi("کمترین"))
        axes[0].plot(1, stats["q1"], marker="D", color="purple", markersize=8, label=fix_farsi("چارک اول"))
        axes[0].plot(1, stats["median"], marker="o", color="black", markersize=9, label=fix_farsi("میانه"))
        axes[0].plot(1, stats["q3"], marker="D", color="purple", markersize=8, label=fix_farsi("چارک سوم"))
        axes[0].plot(1, stats["max"], marker="*", color="blue", markersize=12, label=fix_farsi("بیشترین"))
        axes[0].legend(loc="upper right")

        # --- Histogram ---
        counts, bins, patches = axes[1].hist(scores, bins=10, edgecolor="black", alpha=0.9)
        axes[1].set_title(fix_farsi(" توزیع نمرات"), fontsize=13, weight="bold")
        axes[1].set_xlabel(fix_farsi("نمره"))
        axes[1].set_ylabel(fix_farsi("تعداد"))
        axes[1].set_facecolor("#f9f9f9")
        axes[1].grid(axis="y", linestyle="--", alpha=0.4)
        for patch, left in zip(patches, bins):
            center = left + (bins[1] - bins[0]) / 2
            if center < 10:
                patch.set_facecolor("#ef5350")
            elif center >= 15:
                patch.set_facecolor("#66bb6a")
            else:
                patch.set_facecolor("#ffee58")
        for count, x in zip(counts, bins):
            if count > 0:
                axes[1].text(x + (bins[1] - bins[0]) / 2, count, str(int(count)),
                             ha="center", va="bottom", fontsize=9, weight="bold")

        axes[1].axvline(stats["mean"], color="red", linestyle="--", linewidth=1.5, label=fix_farsi("میانگین"))
        axes[1].axvline(stats["mean"] + stats["std"], color="orange", linestyle=":", linewidth=1.2,
                        label=fix_farsi("±σ انحراف معیار"))
        axes[1].axvline(stats["mean"] - stats["std"], color="orange", linestyle=":", linewidth=1.2)
        axes[1].legend(loc="upper right")

        fig.text(0.5, 0.01, fix_farsi(f" تعداد دانش‌آموزان: {len(scores)}"),
                 ha="center", fontsize=11, color="gray")

        plt.tight_layout(rect=[0, 0.03, 1, 0.96])
        tmp_file = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
        plt.savefig(tmp_file.name, bbox_inches="tight")

        return tmp_file.name

    except Exception as e:
        # مدیریت خطاهای پیش‌بینی نشده در زمان اجرای رسم نمودار
        logging.exception(f"❌ خطای پیش‌بینی نشده در تولید نمودار: {e}")
        return None

    finally:
        # 3. اطمینان از بسته شدن نمودار در هر حالتی (موفق یا ناموفق)
        if fig:
            plt.close(fig)


# ----------------- توابع کمکی -----------------
# فراخوانی نمرات یک دانش اموز با در یک درس و در یک دوره
def _safe_prev_score_lookup(student_id, subject_id, report_period_id):
    try:
        prev = get_student_score(student_id, subject_id, report_period_id)
    except Exception:
        logging.exception("❌ خطا در _safe_prev_score_lookup هنگام فراخوانی get_student_score")
        return None
    if prev is None:
        return None
    if isinstance(prev, dict):
        return {"score": prev.get("score"), "description": prev.get("description")}
    if isinstance(prev, (tuple, list)):
        if len(prev) == 2:
            return {"score": prev[0], "description": prev[1]}
        if len(prev) == 3:
            return {"score": prev[1], "description": prev[2]}
    return None


# گزارش کلاس در یک درس
def summarize_class(subject_name, students_scores, class_name):
    """
    محاسبه آمار نمرات کلاس از روی خروجی get_students_scores_by_class
    """
    try:

        scores_list = [s["score"] for s in students_scores if s["score"] is not None]

        if not scores_list:
            return f"📊 برای درس {subject_name} هیچ نمره‌ای ثبت نشده است.", scores_list

        scores_list.sort()
        n = len(scores_list)

        avg = round(sum(scores_list) / n, 2)
        q1 = round(scores_list[int(0.25 * n)], 2)
        median = round(scores_list[int(0.5 * n)], 2)
        q3 = round(scores_list[int(0.75 * n)], 2)
        min_score = scores_list[0]
        max_score = scores_list[-1]
        below_10 = len([s for s in scores_list if s < 10])
        between_10_15 = len([s for s in scores_list if 10 <= s < 15])
        above_15 = len([s for s in scores_list if s >= 15])
        variance = sum((s - avg) ** 2 for s in scores_list) / n
        std_dev = round(variance ** 0.5, 2)
        counts = Counter(scores_list)
        mode_score, mode_freq = counts.most_common(1)[0]

        summary_msg = (
            f"📊 خلاصه وضعیت کلاس {subject_name} {class_name}:\n"
            f"📊 تعداد کل دانش‌آموزان کلاس: {len(students_scores)}\n"
            f"👥 تعداد دانش‌آموزان با نمره: {n}\n"
            f"📈 میانگین: {avg}\n"
            f"📉 انحراف معیار: {std_dev}\n"
            f"🔽 کمترین نمره: {min_score}\n"
            f"🔼 بیشترین نمره: {max_score}\n"
            f"➗ میانه: {median}\n"
            f"📐 چارک اول: {q1}\n"
            f"📐 چارک سوم: {q3}\n"
            f"🎯 پرتکرارترین نمره: {mode_score} (تکرار {mode_freq} بار)\n"
            f"⚠️ تعداد زیر ۱۰: {below_10}\n"
            f"〰️ تعداد بین ۱۰ تا ۱۵: {between_10_15}\n"
            f"🏆 تعداد ۱۵ و بالاتر: {above_15}"
        )
        if "_@_error_@_" not in (response := get_chatbot_response(role="teacher", user_question=" " + summary_msg)):
            summary_msg += "\n\n" + "━" * 20 + "\n"
            summary_msg += " 🧠  " + response
        return summary_msg, scores_list

    except Exception:
        logging.exception("❌ خطا در summarize_class")
        return f"❌ خطا در محاسبه خلاصه وضعیت کلاس {subject_name}.", []


# ----------------- رندر منو -----------------
async def render_menu(client, chat_id, user_id):
    try:
        st = teacher_states.get(user_id, {})
        # اگر استیت نبود، مقدار اولیه قرار می‌دهیم
        if not st:
            teacher_states[user_id] = {"step": "select_period"}
            st = teacher_states[user_id]

        step = st.get("step")

        if step == "select_period":
            try:
                ss = get_teacher_school_id(user_id)
                periods = get_report_periods_teachers(ss)
            except Exception:
                logging.exception("❌ خطا در دریافت دوره‌ها در render_menu")
                await client.send_message(chat_id, "❌ خطا در دریافت دوره‌ها. لطفاً بعداً تلاش کنید.")
                return
            msg = "📅 لطفاً شماره دوره را انتخاب کنید:\n"
            periods_map = {}
            for i, p in enumerate(periods, 1):
                msg += f"{i}. {p[1]}\n"
                periods_map[str(i)] = p
            msg += "\n'*' برای خروج، '#' برای بازگشت."
            st["periods_map"] = periods_map
            teacher_states[user_id] = st
            await client.send_message(chat_id, msg)
            return

        if step == "select_subject":
            try:
                subjects = get_subjects_by_teacher(user_id)
            except Exception:
                logging.exception("❌ خطا در get_subjects_by_teacher در render_menu")
                await client.send_message(chat_id, "❌ خطا در دریافت دروس.")
                teacher_states.pop(user_id, None)
                return
            msg = "📚 لطفاً شماره درس را انتخاب کنید:\n"
            subjects_map = {}
            for i, s in enumerate(subjects, 1):
                subject_id, subject_name, class_id = s
                try:
                    class_info = get_class_by_id(class_id)
                    class_name = class_info[1] if class_info else ""
                except Exception:
                    logging.exception("❌ خطا در get_class_by_id در render_menu")
                    class_name = ""
                msg += f"{i}. {subject_name} {class_name}\n"
                subjects_map[str(i)] = (subject_id, subject_name, class_id, class_name)  # <-- نام کلاس اضافه شد
            msg += "\n'*' برای خروج، '#' برای بازگشت."
            st["subjects_map"] = subjects_map
            teacher_states[user_id] = st
            await client.send_message(chat_id, msg)
            return

        if step == "choose_action":
            actions_msg = (
                f"📘 درس: {st.get('subject_name', '')} {st.get('class_name')}\n"
                "عملیات را انتخاب کنید:\n"
                "1. ثبت / ویرایش نمرات همه دانش‌آموزان کلاس\n"
                "2. مشاهده خلاصه وضعیت کلاس\n"
                "3. ثبت / ویرایش نمره یک دانش‌آموز خاص\n"
                "'*' برای خروج، '#' برای بازگشت."
            )
            await client.send_message(chat_id, actions_msg)
            return

        if step == "enter_score":
            idx = st.get("current_index", 0)
            students = st.get("students", [])
            if idx >= len(students):
                # حالت غیرمنتظره — بازگشت به منو
                st["step"] = "choose_action"
                teacher_states[user_id] = st
                await client.send_message(chat_id, "⚠️ خطا در شاخص دانش‌آموز — بازگشت به منو.")
                await render_menu(client, chat_id, user_id)
                return
            student_id, student_name = students[idx]
            prev = _safe_prev_score_lookup(student_id, st.get("subject_id"), st.get("report_period_id"))
            msg = f"👨‍🎓 وارد کردن نمره برای: {student_name}\n"
            if prev:
                msg += f"نمره قبلی: {prev.get('score')}, توضیح: {prev.get('description')}\n"
            msg += "لطفاً نمره را وارد کنید (عدد) یا '-' برای رد کردن. '*' برای خروج، '#' برای بازگشت."
            await client.send_message(chat_id, msg)
            return

        if step == "enter_description":
            await client.send_message(chat_id, "📝 توضیحات نمره؟ (برای رد شدن '-' بزنید) '*' برای خروج، '#' برای بازگشت")
            return

        if step == "enter_score_single":
            student_id, student_name = st.get("current_student", ("?", "?"))
            prev = _safe_prev_score_lookup(student_id, st.get("subject_id"), st.get("report_period_id"))
            msg = f"👨‍🎓 وارد کردن نمره برای: {student_name}\n"
            if prev:
                msg += f"نمره قبلی: {prev.get('score')}, توضیح: {prev.get('description')}\n"
            msg += "لطفاً نمره را وارد کنید (عدد) یا '-' برای رد کردن. '*' برای خروج، '#' برای بازگشت."
            await client.send_message(chat_id, msg)
            return

        if step == "enter_description_single":
            await client.send_message(chat_id, "📝 توضیحات نمره؟ (برای رد شدن '-' بزنید) '*' برای خروج، '#' برای بازگشت")
            return

    except Exception:
        logging.exception("❌ خطا در render_menu")
        try:
            await client.send_message(chat_id, "⚠️ خطا در نمایش منو. لطفاً دوباره تلاش کنید.")
        except Exception:
            logging.exception("❌ خطا در ارسال پیام خطا به کاربر در render_menu")


# ----------------- هندلر اصلی -----------------
async def handle_teacher_message(client, chat_id, user_id, text, name):
    try:
        text = text.strip()
        text = normalize_digits(text)  # ← نرمال‌سازی اعداد

        st = teacher_states.get(user_id, {})

        # خروج کامل
        if text in ("/خروج", "*", "خروج"):
            teacher_states.pop(user_id, None)
            await client.send_message(chat_id, "✅ از حالت معلم خارج شدید. برای شروع مجدد /start را ارسال کنید.")
            return "RESET_SESSION"  # ارسال سیگنال برای ریست کامل به فایل اصلی

        # بازگشت به منوی قبلی
        if text == "#":
            step = st.get("step")
            if step == "select_subject":
                st["step"] = "select_period"
            elif step == "choose_action":
                st["step"] = "select_subject"
            elif step in ("enter_score", "enter_description"):
                st["step"] = "choose_action"
            elif step == "select_student":
                st["step"] = "choose_action"
            teacher_states[user_id] = st
            await client.send_message(chat_id, "🔙 به منوی قبلی بازگشتید.")
            await render_menu(client, chat_id, user_id)
            return

        # مرحلهٔ اولیه
        if not st:
            teacher_states[user_id] = {"step": "select_period"}
            await render_menu(client, chat_id, user_id)
            return

        step = st.get("step")

        # ---------------- انتخاب دوره ----------------
        if step == "select_period":
            selected = st.get("periods_map", {}).get(text)
            if not selected:
                await client.send_message(chat_id, "❌ شماره دوره نامعتبر است. '*' برای خروج، '#' برای بازگشت.")
                return
            st["report_period_id"] = selected[0]
            st["step"] = "select_subject"
            teacher_states[user_id] = st
            await render_menu(client, chat_id, user_id)
            return

        # ---------------- انتخاب درس ----------------
        if step == "select_subject":
            sel = st.get("subjects_map", {}).get(text)
            if not sel:
                await client.send_message(chat_id, "❌ شماره درس نامعتبر است. '*' برای خروج، '#' برای بازگشت.")
                return
            subject_id, subject_name, class_id, class_name = sel  # <-- نام کلاس هم دریافت می‌شود
            st.update(
                {"subject_id": subject_id, "subject_name": subject_name, "class_id": class_id, "class_name": class_name,
                 "step": "choose_action"})  # <-- نام کلاس به state اضافه شد
            teacher_states[user_id] = st
            await render_menu(client, chat_id, user_id)
            return

        # ---------------- انتخاب عملیات ----------------
        if step == "choose_action":
            if text == "1":
                try:
                    students = get_students_by_class(st["class_id"])
                except Exception:
                    logging.exception("❌ خطا در get_students_by_class گزینه 1")
                    await client.send_message(chat_id, "❌ خطا در دریافت دانش‌آموزان.")
                    teacher_states.pop(user_id, None)
                    return
                if not students:
                    await client.send_message(chat_id, "❌ هیچ دانش‌آموزی یافت نشد.")
                    teacher_states.pop(user_id, None)
                    return
                st.update({"students": students, "current_index": 0, "step": "enter_score"})
                teacher_states[user_id] = st
                await render_menu(client, chat_id, user_id)
                return

            elif text == "2":
                try:
                    students_scores = get_students_scores_by_class(
                        st["class_id"], st["subject_id"], st["report_period_id"]
                    )
                    report, scores_list = summarize_class(
                        st['subject_name'], students_scores, st.get('class_name', '')
                    )
                    await client.send_message(chat_id, to_persian_digits( report))

                    # تلاش برای ساخت، ارسال و حذف امن نمودار
                    if scores_list:
                        chart_path = None  # متغیر را برای استفاده در finally تعریف می‌کنیم
                        try:
                            chart_path = generate_class_summary_chart_robust(
                                scores_list,
                                class_name=st.get("class_name", ""),
                                subject_name=st.get('subject_name', ''),
                                name=name
                            )
                            if chart_path:
                                # 1. فایل را با 'with' باز کرده و شیء فایل را به send_photo می‌دهیم
                                with open(chart_path, "rb") as photo_file:
                                    await client.send_photo(
                                        chat_id,
                                        photo=photo_file,
                                        caption=f"تحلیل آماری نمرات {st.get('subject_name', '')} {st.get('class_name', '')}: {name} \n {jdatetime.datetime.now().strftime(' %d %m %Y')}"
                                    )
                            else:
                                await client.send_message(chat_id, "⚠️ تولید نمودار موفقیت‌آمیز نبود.")
                        except Exception as e:
                            logging.exception(f"❌ خطا در تولید یا ارسال نمودار (گزینه 2): {e}")
                            await client.send_message(chat_id, "⚠️ خطا در تولید نمودار.")
                        finally:
                            # 2. در هر صورت فایل موقت را بعد از اتمام کار 'with' حذف می‌کنیم
                            if chart_path and os.path.exists(chart_path):
                                try:
                                    os.unlink(chart_path)
                                except Exception as e:
                                    logging.error(f"❌ خطا در حذف فایل نمودار موقت: {e}")

                except Exception as e:
                    logging.exception(f"❌ خطا در دریافت یا خلاصه‌سازی نمرات (گزینه 2): {e}")
                    await client.send_message(chat_id, "❌ خطا در دریافت اطلاعات کلاس.")

                # در هر صورت (موفق یا ناموفق)، کاربر را به منوی عملیات برگردان
                finally:
                    st["step"] = "choose_action"
                    teacher_states[user_id] = st
                    await client.send_message(chat_id, "👇 لطفاً عملیات بعدی را انتخاب کنید.")
                    await render_menu(client, chat_id, user_id)
                return

            elif text == "3":
                try:
                    students = get_students_by_class(st["class_id"])
                except Exception:
                    logging.exception("❌ خطا در get_students_by_class گزینه 3")
                    await client.send_message(chat_id, "❌ خطا در دریافت دانش‌آموزان.")
                    return
                if not students:
                    await client.send_message(chat_id, "❌ هیچ دانش‌آموزی یافت نشد.")
                    return

                msg = "👨‍🎓 لطفاً شماره دانش‌آموز را انتخاب کنید:\n"
                students_map = {}
                for i, (student_id, student_name) in enumerate(students, 1):
                    msg += f"{i}. {student_name}\n"
                    prev = _safe_prev_score_lookup(student_id, st["subject_id"], st["report_period_id"])
                    if prev:
                        msg += f"نمره قبلی: {prev.get('score')}, توضیح: {prev.get('description')}\n"
                    students_map[str(i)] = (student_id, student_name)
                msg += "\n'*' برای خروج، '#' برای بازگشت."

                st.update({
                    "students_map": students_map,
                    "step": "select_student"
                })
                teacher_states[user_id] = st
                await client.send_message(chat_id, msg)
                return

            else:
                await client.send_message(chat_id,
                                          "لطفاً یکی از گزینه‌های 1 تا 3 را وارد کنید یا '*' برای خروج، '#' برای بازگشت.")
                return

        if step == "select_student":
            selected = st.get("students_map", {}).get(text)
            if not selected:
                await client.send_message(chat_id, "❌ شماره دانش‌آموز نامعتبر است. '*' برای خروج، '#' برای بازگشت.")
                return
            student_id, student_name = selected
            st.update({
                "current_student": (student_id, student_name),
                "step": "enter_score_single"
            })
            teacher_states[user_id] = st
            await render_menu(client, chat_id, user_id)
            return

        if step == "enter_score_single":
            if text == "-":
                st["current_score"] = None
            else:
                try:
                    score = float(text)
                    if not (0 <= score <= 20):
                        await client.send_message(chat_id, "❌ نمره باید بین 0 تا 20 باشد.")
                        return
                    st["current_score"] = score
                except ValueError:
                    await client.send_message(chat_id, "❌ لطفاً فقط عدد وارد کنید یا '-' برای رد کردن.")
                    return

            st["step"] = "enter_description_single"
            teacher_states[user_id] = st
            await render_menu(client, chat_id, user_id)
            return

        if step == "enter_description_single":
            description = None if text == "-" else text
            student_id, _ = st["current_student"]
            if st.get("current_score") is not None or description:
                try:
                    save_student_score(student_id, st["subject_id"], st["report_period_id"], st["current_score"],
                                       description)
                except Exception:
                    logging.exception("❌ خطا در save_student_score (single)")
                    await client.send_message(chat_id, "❌ خطا در ذخیرهٔ نمره.")
                    teacher_states.pop(user_id, None)
                    return
            await client.send_message(chat_id, f"✅ نمره دانش‌آموز ثبت شد.")
            st.pop("current_student", None)
            st.pop("current_score", None)
            st["step"] = "choose_action"
            teacher_states[user_id] = st
            await render_menu(client, chat_id, user_id)
            return

        # ---------------- وارد کردن نمره ----------------
        if step == "enter_score":
            if text == "-":
                st["current_score"] = None
            else:
                try:
                    score = float(text)
                    if not (0 <= score <= 20):
                        await client.send_message(chat_id, "❌ نمره باید بین 0 تا 20 باشد.")
                        return
                    st["current_score"] = score
                except ValueError:
                    await client.send_message(chat_id, "❌ لطفاً فقط عدد وارد کنید یا '-' برای رد کردن.")
                    return

            st["step"] = "enter_description"
            teacher_states[user_id] = st
            await render_menu(client, chat_id, user_id)
            return

        # ---------------- توضیحات و ذخیره ----------------
        if step == "enter_description":
            description = None if text == "-" else text
            idx = st.get("current_index", 0)
            students = st.get("students", [])
            if idx >= len(students):
                logging.error("❌ اندیس فعلی بیش از طول لیست دانش‌آموزان است در enter_description")
                teacher_states.pop(user_id, None)
                await client.send_message(chat_id, "❌ خطا در وضعیت داخلی. عملیات متوقف شد.")
                return
            student_id, _ = students[idx]
            if st.get("current_score") is not None or description:
                try:
                    save_student_score(student_id, st["subject_id"], st["report_period_id"], st["current_score"],
                                       description)
                except Exception:
                    logging.exception("❌ خطا در save_student_score (batch)")
                    await client.send_message(chat_id, "❌ خطا در ذخیرهٔ نمره.")
                    teacher_states.pop(user_id, None)
                    return
            st["current_index"] = idx + 1
            if st["current_index"] < len(students):
                st["step"] = "enter_score"
                teacher_states[user_id] = st
                await render_menu(client, chat_id, user_id)
                return
            else:
                await client.send_message(chat_id, "✅ ثبت نمرات همه دانش‌آموزان پایان یافت.")
                st.pop("students", None)
                st.pop("current_index", None)
                st.pop("current_score", None)
                st["step"] = "choose_action"
                teacher_states[user_id] = st
                await render_menu(client, chat_id, user_id)
                return


    except Exception:
        logging.exception("❌ خطا غیرمنتظره در handle_teacher_message")
        try:
            await client.send_message(chat_id, "⚠️ خطای سیستمی رخ داد. لطفاً دوباره تلاش کنید.")
        except Exception:
            logging.exception("❌ خطا در ارسال پیام خطا به کاربر در handle_teacher_message")
