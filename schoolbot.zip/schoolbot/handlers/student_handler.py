import logging
import tempfile
import textwrap
import os
import logging
import tempfile
from collections import defaultdict
from typing import List, Tuple, Optional, Dict

import matplotlib.pyplot as plt
import numpy as np
from bidi.algorithm import get_display
import arabic_reshaper
from matplotlib import rcParams

import uuid
import tempfile
from collections import defaultdict

import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, Optional

import jdatetime
import matplotlib.pyplot as plt
import arabic_reshaper
from bidi.algorithm import get_display
from matplotlib import rcParams
import numpy as np
from typing import List, Tuple, Optional, Dict
from adjustText import adjust_text

from schoolbot.services.open_ai_response import get_chatbot_response
from schoolbot.services.score_service import (
    get_report_periods,
    get_student_scores,
    calculate_weighted_average,
    get_class_average_scores,
    get_student_rank,
    get_student_all_scores,
    get_rank_context_counts,
    get_school_id_by_student,
    generate_multi_subject_charts,
    get_top_students, get_class_averages_for_all_periods,
)
from schoolbot.utils.keyboards import normalize_digits, to_persian_digits

# ------------------ تنظیم logging ------------------
logging.basicConfig(
    level=logging.ERROR,  # فقط خطاها ثبت شوند
    format="%(asctime)s - [%(levelname)s] - %(message)s"
)
logger = logging.getLogger(__name__)



student_states = {}  # ذخیره وضعیت دانش‌آموزان

# ------------------ نگاشت ایموجی برای دروس ------------------
SUBJECT_EMOJIS = {
    "ریاضی": "📐",
    "علوم": "🧪",
    "علوم تجربی": "🧪",
    "فارسی": "📖",
    "املا": "✍️",
    "قرآن": "📜",
    "عربی": "🔤",
    "زبان انگلیسی": "🗣️",
    "مطالعات اجتماعی": "🌍",
    "هنر": "🎨",
    "ورزش": "🏃",
    "کامپیوتر": "🖥️",
    "دینی": "🕌",
}


def best_rank_format(top_students):
    lines = []
    col_widths = {"ردیف": 6, "نام": 15, "کلاس": 10, "معدل": 6}
    row_format = f"{{:<{col_widths['ردیف']}}} {{:<{col_widths['نام']}}} {{:<{col_widths['کلاس']}}} {{:<{col_widths['معدل']}}}"
    lines.append("━" * 20)
    header = row_format.format("ردیف", "نام", "کلاس", "معدل")
    lines.append(header)
    lines.append("━" * 20)

    for i, stu in enumerate(top_students, 1):
        name_lines = textwrap.wrap(stu["name"], width=col_widths["نام"])
        if not name_lines:
            name_lines = [""]
        for j, name_part in enumerate(name_lines):
            name_fixed = name_part.ljust(col_widths["نام"])
            if j == 0:
                line = row_format.format(i, name_fixed, stu["class"], stu["avg"])
            else:
                line = row_format.format("", name_fixed, "", "")
            lines.append(line)
    return lines


def format_periods(periods):
    msg = "📅 لطفاً شماره دوره را انتخاب کنید:\n"
    for i, p in enumerate(periods, 1):
        msg += f"{i}. {p[1]}\n"
    msg += "\n🔸 برای بازگشت «#» و برای خروج کامل «*»"
    return msg


def _categorize_score(score):
    if score is None:
        return "❔", "ثبت نشده"
    s = float(score)
    if s >= 17:
        return "🟢", "عالی"
    if s >= 12:
        return "🟡", "متوسط"
    return "🔴", "تلاش بیشتر"


def _subject_emoji(name):
    for key, emoji in SUBJECT_EMOJIS.items():
        if key in name:
            return emoji
    return "📚"


def _format_rank_with_total(rank, total):
    if rank is None or not total:
        return None
    return f"{rank} از {total}"


def generate_combined_chart(student_scores, class_avg_scores, name, report_name):
    try:
        def fix_farsi(text: str) -> str:
            return get_display(arabic_reshaper.reshape(text))

        subjects = [fix_farsi(s[0]) for s in student_scores]
        student_values = [float(s[1]) if s[1] is not None else 0 for s in student_scores]
        class_dict = {fix_farsi(c[0]): c[1] for c in class_avg_scores}
        class_avg_values = [float(class_dict.get(sub, 0)) for sub in subjects]

        x = np.arange(len(subjects))
        plt.figure(figsize=(14, 7))

        bar_colors = []
        for s_val, c_val in zip(student_values, class_avg_values):
            if s_val > c_val:
                bar_colors.append("mediumseagreen")
            elif s_val < c_val:
                bar_colors.append("tomato")
            else:
                bar_colors.append("lightgray")

        bars = plt.bar(x, class_avg_values, color=bar_colors, alpha=0.8, width=0.6, label=fix_farsi("میانگین کلاس"))

        plt.plot(x, student_values, marker='o', markersize=9, linestyle='-', color='royalblue',
                 linewidth=2.5, label=fix_farsi("نمره شما"), zorder=5)

        for i, b in enumerate(bars):
            h = b.get_height()
            plt.text(b.get_x() + b.get_width() / 2, h * 0.1, f"{h:.1f}",
                     ha='center', va='bottom', fontsize=9, color="white", fontweight="bold")

        for xi, y in zip(x, student_values):
            plt.text(xi, y + 0.5, f"{y:.1f}", ha='center', va='bottom', fontsize=9, color="blue")

        plt.xticks(x, subjects, rotation=0, fontsize=11)
        plt.yticks([0, 5, 10, 15, 20], fontsize=11)
        plt.ylim(0, 21)

        plt.xlabel(fix_farsi("دروس"), fontsize=13)
        plt.ylabel(fix_farsi("نمره"), fontsize=13)
        plt.title(fix_farsi(f" مقایسه نمرات {name} با میانگین کلاس دوره:  {report_name} "), fontsize=15,
                  fontweight="bold")

        plt.grid(axis="y", linestyle="--", alpha=0.5, zorder=0)
        for spine in ["top", "right"]:
            plt.gca().spines[spine].set_visible(False)

        plt.legend(fontsize=11)

        tmp_file = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
        plt.savefig(tmp_file.name, bbox_inches="tight", dpi=300)
        plt.close()
        return tmp_file.name
    except Exception as e:
        logger.error("❌ خطا در تولید نمودار: %s", str(e))
        return None




# توجه: نوع ورودی data تغییر کرده است
def generate_radar_chart(data: Dict[str, Dict[str, Dict[str, float]]], name: str) -> Optional[str]:
    """
    برای هر دوره یک نمودار راداری برای دانش‌آموز و میانگین کلاس تولید کرده
    و همه را در یک تصویر نمایش می‌دهد.
    """

    def fix_farsi(text: str) -> str:
        return get_display(arabic_reshaper.reshape(str(text)))

    if not data or not list(data.values()):
        return None

    # استخراج لیبل‌ها از اولین آیتم
    first_period_data = list(data.values())[0]
    labels = list(first_period_data['student_scores'].keys())
    # ✨ تغییر اصلی اینجاست
    # برای دو برچسب خاص، یک خط جدید در ابتدا اضافه می‌کنیم تا فاصله بگیرند
    farsi_labels = [
        fix_farsi('\n\n' + label) if label in ['علمی', 'اجتماعی سیاسی'] else fix_farsi(label)
        for label in labels
    ]

    num_vars = len(labels)

    color_map = {
        'زیستی بدنی': 'green', 'علمی': 'deepskyblue', 'اعتقادی عبادی': 'orange',
        'اجتماعی سیاسی': 'purple', 'اقتصادی حرفه ای': 'red', 'هنری زیبائی': 'blue'
    }

    angles = np.linspace(0, 2 * np.pi, num_vars, endpoint=False).tolist()
    angles += angles[:1]

    num_plots = len(data)
    cols = int(np.ceil(np.sqrt(num_plots)))
    rows = int(np.ceil(num_plots / cols))

    fig, axes = plt.subplots(figsize=(cols * 6, rows * 6), nrows=rows, ncols=cols,
                             subplot_kw=dict(polar=True))
    axes = np.ravel(axes)

    for i, (period_name, period_scores) in enumerate(data.items()):
        ax = axes[i]

        student_scores = period_scores['student_scores']
        average_scores = period_scores['average_scores']

        # --- آماده‌سازی داده‌های دانش‌آموز ---
        values_student = [student_scores.get(label, 0) for label in labels]
        closed_values_student = values_student + values_student[:1]

        # --- آماده‌سازی داده‌های میانگین کلاس ---
        values_avg = [average_scores.get(label, 0) for label in labels]
        closed_values_avg = values_avg + values_avg[:1]

        # --- رسم نمودار دانش‌آموز (خط ممتد و ناحیه پر شده) ---
        ax.plot(angles, closed_values_student, color='royalblue', linewidth=2, label=fix_farsi('نمره دانش‌آموز'))
        ax.fill(angles, closed_values_student, color='royalblue', alpha=0.2)

        # --- رسم نمودار میانگین کلاس (خط‌چین) ---
        ax.plot(angles, closed_values_avg, color='darkorange', linewidth=2, linestyle='--',
                label=fix_farsi('میانگین کلاس'))

        # نقاط رنگی و متن فقط برای نمرات دانش‌آموز (برای جلوگیری از شلوغی)
        plot_colors = [color_map.get(label, 'gray') for label in labels]
        ax.scatter(angles[:-1], values_student, c=plot_colors, s=80, zorder=10)
        for angle, value in zip(angles[:-1], values_student):
            ax.text(angle, value + 1.8, f'{value}', ha='center', va='center', fontweight='bold', color='black')

        ax.set_yticks([0, 5, 10, 15, 20])
        ax.set_ylim(0, 20)

        ax.set_thetagrids(np.degrees(angles[:-1]), farsi_labels)
        ax.set_title(fix_farsi(period_name), y=1.15, fontdict={'fontsize': 14})
        ax.tick_params(axis='x', pad=15)

        # جدید: افزودن راهنمای نمودار (legend)
        ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1))

    for i in range(num_plots, len(axes)):
        axes[i].set_visible(False)

    fig.suptitle(fix_farsi(f"نمودار راداری عملکرد: {name}"), fontsize=18, y=0.98)
    plt.tight_layout(pad=3.0)

    tmp_file = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
    plt.savefig(tmp_file.name, bbox_inches="tight", dpi=300)
    plt.close(fig)
    return tmp_file.name

import tempfile
import matplotlib.pyplot as plt
import numpy as np
from bidi.algorithm import get_display
import arabic_reshaper
from matplotlib import rcParams
from typing import Dict, Optional
from adjustText import adjust_text

# تنظیمات اولیه فونت و استایل
# rcParams['font.family'] = 'Tahoma'
# plt.style.use('seaborn-v0_8-whitegrid')



def generate_average_trend_chart(averages: Dict[str, float], name: str,
                                 class_averages_for_all_periods: Optional[Dict[str, float]] = None) -> Optional[str]:
    if not averages:
        return None

    def fix_farsi(text: str) -> str:
        return get_display(arabic_reshaper.reshape(text))

    periods = list(averages.keys())
    scores = list(averages.values())
    x_pos = np.arange(len(periods))
    scores_np = np.array(scores)

    plt.figure(figsize=(12, 7))
    ax = plt.gca()
    texts = []

    # دیکشنری تنظیمات پس‌زمینه برای خوانایی بهتر
    bbox_props = dict(boxstyle='round,pad=0.2', facecolor='white', alpha=0.8, edgecolor='none')

    if class_averages_for_all_periods:
        class_scores = [class_averages_for_all_periods.get(p, np.nan) for p in periods]
        class_scores_np = np.array(class_scores)

        plt.fill_between(x_pos, scores_np, class_scores_np, where=(scores_np >= class_scores_np), color='#98d898',
                         alpha=0.5, interpolate=True, label=fix_farsi("بالاتر از میانگین"))
        plt.fill_between(x_pos, scores_np, class_scores_np, where=(scores_np < class_scores_np), color='#f7a7a4',
                         alpha=0.6, interpolate=True, label=fix_farsi("پایین‌تر از میانگین"))
        plt.plot(x_pos, class_scores_np, '--', color='#ff7f0e', linewidth=2.5, label=fix_farsi("میانگین کلاس"))

        for i, class_avg in enumerate(class_scores_np):
            if not np.isnan(class_avg):
                texts.append(plt.text(x_pos[i], class_avg, f'{class_avg:.2f}', ha='left', va="top", fontweight='bold',
                                      fontsize=8, color='#b35900',
                                      bbox=bbox_props, zorder=20))  # <<< جدید: افزودن پس‌زمینه

    else:
        plt.fill_between(x_pos, scores, color="skyblue", alpha=0.2, zorder=1)

    plt.plot(x_pos, scores, marker='o', markersize=9, linestyle='none', color='royalblue', zorder=5)

    if len(scores) > 1:
        for i in range(1, len(scores)):
            segment_color = 'royalblue'
            delta = scores[i] - scores[i - 1]
            if delta > 0.01:
                segment_color = 'green'
            elif delta < -0.01:
                segment_color = 'red'
            plt.plot([x_pos[i - 1], x_pos[i]], [scores[i - 1], scores[i]], color=segment_color, linewidth=3.5,
                     solid_capstyle='round', zorder=3)
            sign = "+" if delta > 0 else ""
            if abs(delta) > 0.01:
                texts.append(
                    plt.text(x_pos[i], scores[i], f'({sign}{delta:.2f})', ha='right', va="bottom", fontweight='bold',
                             fontsize=8, color=segment_color,
                             bbox=bbox_props, zorder=20))  # <<< جدید: افزودن پس‌زمینه

    for i, score in enumerate(scores):
        texts.append(plt.text(x_pos[i], score, f'{score}', ha='center', va="center", fontweight='bold', color='navy',
                              fontsize=10,
                              bbox=bbox_props, zorder=20))  # <<< جدید: افزودن پس‌زمینه

    if len(scores) > 1:
        z = np.polyfit(x_pos, scores, 1)
        p = np.poly1d(z)
        plt.plot(x_pos, p(x_pos), "--", linewidth=2, color='gray', alpha=0.8, label=fix_farsi("روند کلی دانش‌آموز"))
        slope = z[0]
        if slope > 0.1:
            trend_text, trend_color = fix_farsi("روند کلی: صعودی"), 'darkgreen'
        elif slope < -0.1:
            trend_text, trend_color = fix_farsi("روند کلی: نزولی"), 'darkred'
        else:
            trend_text, trend_color = fix_farsi("روند کلی: ثابت"), 'darkblue'
        ax.text(0.04, 0.04, trend_text, transform=ax.transAxes, fontsize=12, verticalalignment='top', color='white',
                bbox=dict(boxstyle='round,pad=0.4', fc=trend_color, alpha=0.8))

    adjust_text(texts, arrowprops=dict(arrowstyle='-', color='gray', lw=0.5))

    ax.set_facecolor('#f9f9f9')
    plt.title(fix_farsi(f"تحلیل پیشرفت تحصیلی {name}"), fontsize=18, fontweight='bold', color='#333333')
    plt.xlabel(fix_farsi("دوره‌های تحصیلی"), fontsize=14, color='#555555')
    plt.ylabel(fix_farsi("معدل"), fontsize=14, color='#555555')
    plt.xticks(x_pos, [fix_farsi(p) for p in periods], rotation=0, fontsize=12)
    plt.yticks(np.arange(0, 21, 2), fontsize=11)
    plt.ylim(bottom=-0.5)
    for spine in ["top", "right"]: ax.spines[spine].set_visible(False)
    plt.legend(fontsize=12, loc='lower right')
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.tight_layout(pad=1.5)

    try:
        tmp_file = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
        plt.savefig(tmp_file.name, bbox_inches="tight", dpi=300)
        plt.close()
        return tmp_file.name
    except Exception as e:
        print(f"Error saving chart: {e}")
        return None


def calculate_and_plot_averages(all_scores: List[Tuple[str, str, Optional[float],
Optional[str], float, Optional[float]]], name="", class_averages_for_all_periods: Optional[Dict[str, float]] = None) -> \
Optional[str]:
    """
    معدل وزنی هر دوره را محاسبه کرده و نمودار روند را تولید می‌کند.

    خروجی:
        مسیر فایل نمودار تولید شده یا None در صورت خطا.
    """
    period_data = defaultdict(lambda: {"sum_of_products": 0.0, "sum_of_coeffs": 0.0})

    for subject_name, period_name, score, description, coefficient, average_score,teacher_name in all_scores:
        if score is not None and coefficient is not None and coefficient > 0:
            period_data[period_name]["sum_of_products"] += score * coefficient
            period_data[period_name]["sum_of_coeffs"] += coefficient

    averages = {}
    # مرتب‌سازی دوره‌ها بر اساس ترتیب ورود (فرض می‌شود داده‌ها از دیتابیس مرتب آمده‌اند)
    sorted_periods = list(period_data.keys())

    for period_name in sorted_periods:
        data = period_data[period_name]
        sum_of_products = data["sum_of_products"]
        sum_of_coeffs = data["sum_of_coeffs"]

        if sum_of_coeffs > 0:
            average = sum_of_products / sum_of_coeffs
            averages[period_name] = round(average, 2)
        else:
            averages[period_name] = 0.0

    # تولید و بازگرداندن مسیر فایل نمودار
    return generate_average_trend_chart(averages, name, class_averages_for_all_periods)


# ------------------ هندل اصلی پیام‌های دانش‌آموز ------------------
async def handle_student_message(client, chat_id, user_id, text, name=""):
    school_id = get_school_id_by_student(user_id)
    text = normalize_digits(text.strip())
    st = student_states.get(user_id, {})

    if text == "*":
        student_states.pop(user_id, None)
        await client.send_message(chat_id, "✅ از منوی دانش‌آموز خارج شدید. برای شروع دوباره /start را ارسال کنید.")
        return "RESET_SESSION"  # ارسال سیگنال برای ریست کامل به فایل اصلی

    if text == "#":
        prev_step = st.get("prev_step")
        if prev_step:
            st["step"] = prev_step
            st["prev_step"] = None
            student_states[user_id] = st
            if prev_step == "select_period":
                try:
                    periods = get_report_periods(school_id)
                    if periods:
                        await client.send_message(chat_id, format_periods(periods))
                except Exception as e:
                    logger.error("❌ خطا در دریافت دوره‌ها student_id=%s: %s", user_id, str(e))
            return
        else:
            student_states.pop(user_id, None)
            await client.send_message(chat_id, "📋 دوباره شروع کنید: /start")
            return

    if not st:
        try:
            periods = get_report_periods(school_id)
            if not periods:
                await client.send_message(chat_id, "❌ هنوز دوره‌ای ایجاد نشده است.")
                return
            periods_map = {str(i + 1): p for i, p in enumerate(periods)}
            st = {"step": "select_period", "periods_map": periods_map}
            student_states[user_id] = st
            await client.send_message(chat_id, format_periods(periods))
        except Exception as e:
            logger.error("❌ خطا در شروع student_id=%s: %s", user_id, str(e))
        return

    if st.get("step") == "select_period":
        period = st.get("periods_map", {}).get(text)
        if not period:
            await client.send_message(chat_id, "❌ شماره دوره نامعتبر است. دوباره انتخاب کنید یا «*».")
            return

        st["prev_step"] = "select_period"
        st["report_period_id"] = period[0]
        st["report_period_name"] = period[1]
        try:
            student_scores = get_student_scores(user_id, st["report_period_id"])
        except Exception as e:
            logger.error("❌ خطا در دریافت نمرات student_id=%s: %s", user_id, str(e))
            await client.send_message(chat_id, "⚠️ خطا در دریافت نمرات.")
            return

        if not student_scores:
            await client.send_message(chat_id, "📭 هنوز نمره‌ای برای این دوره ثبت نشده.")
        else:
            try:
                header = f"{'درس':<12} {'ضریب':<6} {'نمره':<5} {'توضیحات':<20}"
                lines = [f"📊 کارنامه شما: {name} \n", f"دوره: {st['report_period_name']}", "━" * 20, header, "━" * 20]

                for subj_name, score, desc, coeff in student_scores:
                    score_txt = "—" if score is None else str(score)
                    desc_txt = desc if desc else ""
                    base_line = f"*{subj_name:<12}* {coeff:<6} *{score_txt:<5}* "
                    lines.append(base_line + " " + desc_txt)
                    # wrapped_desc = textwrap.wrap(desc_txt, width=20)
                    # if wrapped_desc:
                    #     lines.append(f"{base_line} _{wrapped_desc[0]}_")
                    #     for extra_line in wrapped_desc[1:]:
                    #         lines.append(" " * len(base_line) + " " + f"_{extra_line}_")
                    # else:
                    #     lines.append(base_line)

                avg = calculate_weighted_average(student_scores)
                if avg is not None:
                    lines.append(f"\n📌 معدل: {avg}")
                    if avg >= 18:
                        lines.append("🏆 فوق‌العاده! تو جزو برترین‌ها هستی!")
                    elif avg >= 14:
                        lines.append("✨ خیلی خوبه! با کمی تمرین بیشتر می‌تونی عالی بشی.")
                    else:
                        lines.append("💪 ناامید نشو! با برنامه‌ریزی بهتر پیشرفت می‌کنی.")

                rank_class, rank_grade, rank_school, top_students = get_student_rank(user_id, st["report_period_id"])
                cnt_class, cnt_grade, cnt_school = get_rank_context_counts(user_id, st["report_period_id"])

                rc = _format_rank_with_total(rank_class, cnt_class)
                rg = _format_rank_with_total(rank_grade, cnt_grade)
                rs = _format_rank_with_total(rank_school, cnt_school)

                lines.append("\n")
                lines.append("رتبه شما")
                lines.append("━" * 20)
                if rc:
                    lines.append(f"🏅 رتبه در کلاس: {rc}")
                if rg:
                    lines.append(f"🎓 رتبه در پایه: {rg}")
                if rs:
                    lines.append(f"🏫 رتبه در مدرسه: {rs}")

                if "_@_error_@_" not in (response := get_chatbot_response(role="student", user_question=str(lines))):
                    lines.append("\n\n" + " 🧠  مشاور:")
                    lines.append(response)

                if top_students.get("class"):
                    lines.append("\n🏅 نفرات برتر کلاس:")
                    lines.extend(best_rank_format(top_students["class"]))
                if top_students.get("grade"):
                    lines.append("\n🎓 نفرات برتر پایه:")
                    lines.extend(best_rank_format(top_students["grade"]))
                if top_students.get("school"):
                    lines.append("\n🏫 نفرات برتر مدرسه:")
                    lines.extend(best_rank_format(top_students["school"]))

                await client.send_message(chat_id, to_persian_digits("\n".join(lines)))

                chart_file = None  # متغیر را برای استفاده در finally تعریف می‌کنیم
                try:
                    class_avg_scores = get_class_average_scores(user_id, st["report_period_id"])
                    chart_file = generate_combined_chart(student_scores, class_avg_scores, name,
                                                         st["report_period_name"])
                    if chart_file:
                        # فایل را با 'with' باز کرده و ارسال می‌کنیم
                        with open(chart_file, "rb") as photo_file:
                            await client.send_photo(
                                chat_id,
                                photo=photo_file,
                                caption=f"📊 نمودار نمرات *{name}* و میانگین کلاس \n"
                                        f"دوره: {st['report_period_name']} \n"
                                        "رنگ سبز: نمره شما از میانگین کلاس بهتره\n"
                                        "رنگ خاکستری: نمره شما با میانگین کلاس یکسان هست\n"
                                        "رنگ قرمز: نمره شما از میانگین کلاس پایین‌تر شده"
                            )
                    else:
                        await client.send_message(chat_id, "⚠️ در تولید نمودار مشکلی پیش آمد.")
                except Exception as e:
                    logger.error("❌ خطا در تولید نمودار student_id=%s: %s", user_id, str(e))
                    await client.send_message(chat_id, "⚠️ در تولید نمودار مشکلی پیش آمد.")
                finally:
                    # در هر صورت فایل موقت را بعد از ارسال حذف می‌کنیم
                    if chart_file and os.path.exists(chart_file):
                        try:
                            os.unlink(chart_file)
                        except Exception as e:
                            logger.error(f"❌ خطا در حذف فایل نمودار مقایسه: {e}")
                all_scores = get_student_all_scores(user_id)
                if not all_scores:
                    await client.send_message(chat_id, "📭 نمره‌ای یافت نشد.")

                else:
                    try:
                        class_averages_for_all_periods = get_class_averages_for_all_periods(user_id)
                        chart_averages = calculate_and_plot_averages(all_scores, name, class_averages_for_all_periods)
                        if chart_averages:
                            # فایل را با 'with' باز کرده و ارسال می‌کنیم
                            with open(chart_averages, "rb") as photo_file:
                                await client.send_photo(
                                    chat_id,
                                    photo=photo_file,
                                    caption=f"📊 نمودار میانگین *{name}* در طول سال \n"

                                )
                        else:
                            await client.send_message(chat_id, "⚠️ در تولید نمودار میانگین ها مشکلی پیش آمد.")
                    except Exception as e:
                        logger.error("❌ خطا در تولید نمودار میانگین ها student_id=%s: %s", user_id, str(e))
                        await client.send_message(chat_id, "⚠️ در تولید نمودار میانگین ها مشکلی پیش آمد.")
                    finally:
                        # در هر صورت فایل موقت را بعد از ارسال حذف می‌کنیم
                        if chart_averages and os.path.exists(chart_averages):
                            try:
                                os.unlink(chart_averages)
                            except Exception as e:
                                logger.error(f"❌ خطا در حذف فایل نمودار مقایسه: {e}")
                    # ------------------ END  chart mean ----------------------

                    # --- بخش جدید: پردازش داده‌ها برای نمودار راداری ---
                    # --- بخش جدید: پردازش داده‌ها برای نمودار راداری (نسخه اصلاح‌شده) ---
                    period_data_student = {}
                    period_data_avg = {}  # جدید: دیکشنری مجزا برای میانگین کلاس

                    # تفکیک نمرات دانش‌آموز و میانگین کلاس
                    for subject, period_name, score, _, _, average_score, _ in all_scores:
                        if period_name not in period_data_student:
                            period_data_student[period_name] = {'ریاضی': [], 'علوم': [], 'ورزش': [], 'هدیه': []}
                            period_data_avg[period_name] = {'ریاضی': [], 'علوم': [], 'ورزش': [], 'هدیه': []}

                        if subject in ['ریاضی', 'علوم', 'ورزش', 'هدیه']:
                            if score is not None:
                                period_data_student[period_name][subject].append(score)
                            if average_score is not None:
                                period_data_avg[period_name][subject].append(average_score)

                    # ساختار نهایی برای ارسال به تابع رسم نمودار
                    processed_for_radar = {}
                    for period, subjects_student in period_data_student.items():
                        subjects_avg = period_data_avg.get(period, {'ریاضی': [], 'علوم': [], 'ورزش': [], 'هدیه': []})

                        # محاسبه ساحت‌ها برای نمرات دانش‌آموز
                        math_science_scores_student = subjects_student['ریاضی'] + subjects_student['علوم']
                        avg_math_science_student = np.mean(
                            math_science_scores_student) if math_science_scores_student else 0.0
                        sport_score_student = np.mean(subjects_student['ورزش']) if subjects_student['ورزش'] else 0.0
                        hediyeh_score_student = np.mean(subjects_student['هدیه']) if subjects_student['هدیه'] else 0.0

                        student_final_scores = {
                            "علمی": round(avg_math_science_student, 2),
                            "زیستی بدنی": round(sport_score_student, 2),
                            "اعتقادی عبادی": round(hediyeh_score_student, 2),
                            "اجتماعی سیاسی": round(
                                np.mean(subjects_student['ریاضی']) if subjects_student['ریاضی'] else 0.0, 2),
                            "اقتصادی حرفه ای": round(
                                np.mean(subjects_student['علوم']) if subjects_student['علوم'] else 0.0, 2),
                            "هنری زیبائی": round(sport_score_student, 2)
                        }

                        # محاسبه ساحت‌ها برای میانگین کلاس
                        math_science_scores_avg = subjects_avg['ریاضی'] + subjects_avg['علوم']
                        avg_math_science_avg = np.mean(math_science_scores_avg) if math_science_scores_avg else 0.0
                        sport_score_avg = np.mean(subjects_avg['ورزش']) if subjects_avg['ورزش'] else 0.0
                        hediyeh_score_avg = np.mean(subjects_avg['هدیه']) if subjects_avg['هدیه'] else 0.0

                        average_final_scores = {
                            "علمی": round(avg_math_science_avg, 2),
                            "زیستی بدنی": round(sport_score_avg, 2),
                            "اعتقادی عبادی": round(hediyeh_score_avg, 2),
                            "اجتماعی سیاسی": round(np.mean(subjects_avg['ریاضی']) if subjects_avg['ریاضی'] else 0.0, 2),
                            "اقتصادی حرفه ای": round(np.mean(subjects_avg['علوم']) if subjects_avg['علوم'] else 0.0, 2),
                            "هنری زیبائی": round(sport_score_avg, 2)
                        }

                        # تجمیع هر دو نتیجه در یک ساختار
                        processed_for_radar[period] = {
                            'student_scores': student_final_scores,
                            'average_scores': average_final_scores
                        }
                    # --- بخش جدید: تولید و ارسال نمودار راداری ---
                    try:
                        radar_chart_path = generate_radar_chart(processed_for_radar, name)
                        if radar_chart_path:
                            try:
                                with open(radar_chart_path, "rb") as photo_file:
                                    await client.send_photo(
                                        chat_id,
                                        photo=photo_file,
                                        caption=f"📊 نمودار راداری عملکرد ساحت های شش گانه ی *{name}*"
                                    )
                            finally:
                                if os.path.exists(radar_chart_path):
                                    os.unlink(radar_chart_path)
                    except Exception as e:
                        logger.error("❌ خطا در تولید یا ارسال نمودار راداری student_id=%s: %s", user_id, str(e))
                    # ----------------------------------------------------
                    try:
                        chart_files = generate_multi_subject_charts(all_scores, name=name)
                        for chart_path in chart_files:
                            # برای هر نمودار، آن را باز کرده، ارسال و سپس حذف می‌کنیم
                            try:
                                with open(chart_path, "rb") as photo_file:
                                    await client.send_photo(
                                        chat_id,
                                        photo=photo_file,
                                        caption=f"📊 نمودار نمرات شما در دوره‌های مختلف *{name}* \n مقایسه با میانگین درس در کلاس"
                                    )
                            finally:
                                # فایل موقت این نمودار را حذف می‌کنیم
                                if os.path.exists(chart_path):
                                    try:
                                        os.unlink(chart_path)
                                    except Exception as e:
                                        logger.error(f"❌ خطا در حذف فایل نمودار تاریخچه: {e}")
                    except Exception as e:
                        logger.error("❌ خطا در تولید نمودار تاریخچه student_id=%s: %s", user_id, str(e))

                    # -------------------------- تاریخچه نمرات ----------------------------------------
                    score_text = "📚 تاریخچه نمرات شما:\n\n"
                    score_text += name + " تاریخ:" + jdatetime.datetime.now().strftime(' %Y/%m/%d ساعت: %H:%M') + "\n"
                    last_scores = {}
                    subLine = ""
                    for subject, period_name, score, desc, coefficient, average_score,teacher_name in all_scores:
                        if subLine != subject:
                            subLine = subject
                            score_text += "\n" + "━" * 20 + "\n"
                            score_text += _subject_emoji(subject) + " " + subject+ f" دبیر: *{teacher_name}*" + "\n"
                            score_text += "نام دوره: نمره --> توضیحات دبیر\n"
                        delta = ""
                        if score is not None:
                            if subject in last_scores and last_scores[subject] is not None:
                                prev = last_scores[subject]
                                if score > prev:
                                    delta = f" (+{round(score - prev, 2)})"
                                elif score < prev:
                                    delta = f" ({round(score - prev, 2)})"
                                else:
                                    delta = " (0)"
                            last_scores[subject] = score
                        else:
                            last_scores[subject] = None

                        score_show = "—" if score is None else f"{score}{delta}"
                        add_note = f" 👨‍🏫 {desc}" if desc else ""
                        score_text += f"• {period_name}: {score_show} --> {add_note} --> میانگین کلاس: {round(average_score, 2)} \n"

                    await client.send_message(chat_id, to_persian_digits(score_text))

            except Exception as e:
                logger.error("❌ خطا در ساخت کارنامه student_id=%s: %s", user_id, str(e))
                await client.send_message(chat_id, "⚠️ در تولید کارنامه مشکلی پیش آمد.")

        student_states[user_id] = st
        await client.send_message(chat_id, "🔸 برای مشاهده کارنامه دیگر شماره آن را بفرستید.\n"
                                           "🔹 برای بازگشت «#» و خروج کامل «*».")
