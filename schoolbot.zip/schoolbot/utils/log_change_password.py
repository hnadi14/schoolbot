from datetime import datetime
import json

import jdatetime


def log_attributes_user_student_change_pass(source_object, national_id_number):
    """
    ویژگی‌های مشخص شده را از یک شیء استخراج کرده، در یک فایل لاگ می‌نویسد
    و سپس آن‌ها را به صورت یک دیکشنری برمی‌گرداند.

    Args:
        source_object: شیء مبدا که اطلاعات در آن قرار دارد (مانند message.author).
        log_file (str): مسیر فایلی که لاگ‌ها در آن ذخیره می‌شوند.

    Returns:
        dict: یک دیکشنری جدید که فقط شامل ویژگی‌های موجود است.
    """
    log_file = "user_activity.log"
    # لیستی از ویژگی‌هایی که می‌خواهیم
    fields_we_want = ["id", "is_bot", "first_name", "last_name", "username"]
    extracted_data = {}
    for field in fields_we_want:
        if hasattr(source_object, field):
            extracted_data[field] = getattr(source_object, field)

    # --- بخش جدید: نوشتن در فایل لاگ ---
    try:
        # 1. گرفتن تاریخ و زمان فعلی شمسی
        now = jdatetime.datetime.now()
        timestamp = now.strftime('%Y-%m-%d %H:%M:%S')

        # 2. ساخت یک دیکشنری کامل برای ثبت در لاگ
        log_entry = {
            "timestamp": timestamp,
            "date_time":datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "national_id_number":national_id_number,
            "user_data": extracted_data
        }

        # 3. باز کردن فایل در حالت append و نوشتن لاگ به صورت یک خط JSON
        with open(log_file, "a", encoding="utf-8") as f:
            # از json.dumps برای تبدیل دیکشنری پایتون به رشته JSON استفاده می‌کنیم
            f.write(json.dumps(log_entry, ensure_ascii=False) + "\n")

    except Exception as e:
        # اگر در نوشتن لاگ خطایی رخ داد، برنامه اصلی متوقف نشود
        print(f"خطایی در نوشتن لاگ رخ داد: {e}")
    # ------------------------------------
    return

def user_bale_info(source_object) -> str:
    info = ""
    try:
        info += f"id: {source_object['id']}\n"
    except Exception as e:
        info += ""
    try:
        info += f"نام شما: {source_object['full_name']}\n"
    except Exception as e:
        info += ""
    try:
        info += f"نام کاربری شما: {source_object['username']}\n"
    except Exception as e:
        info += ""

    return info
