import logging

import jdatetime
import matplotlib.pyplot as plt
import numpy as np
import tempfile
import arabic_reshaper
from adjustText import adjust_text
from bidi.algorithm import get_display
import logging

# This will hide the INFO and DEBUG messages from the adjustText library
logging.getLogger('adjustText').setLevel(logging.WARNING)

def format_school_multi_period_analysis(analysis: dict, name):
    """
    تولید متن تحلیلی چند دوره‌ای + نمودارهای تحلیلی برای مدیر
    خروجی: (text:str, chart_file:str|None)
    تمام خطاهای عددی/ترسیمی هندل می‌شوند تا تابع همیشه خروجی معتبر بدهد.
    """

    log = logging.getLogger(__name__)

    # 📝 اصلاح متن فارسی
    def fix_farsi(text: str) -> str:
        try:
            return get_display(arabic_reshaper.reshape(str(text)))
        except Exception:
            # اگر کتابخانه‌ها خطا دادند، متن خام را برگردان
            return str(text)

    # اگر سرویس تحلیل پیام آماده داشته باشد
    if isinstance(analysis, dict) and "message" in analysis:
        return str(analysis.get("message") or ""), None

    # اگر analysis ساختار درست ندارد
    if not isinstance(analysis, dict):
        return "⚠️ داده‌ی تحلیل نامعتبر است.", None

    txt = f"📊 گزارش تحلیلی مدرسه {name} در تمام دوره‌ها:\n{jdatetime.datetime.now().strftime(' %Y/%m/%d')} \n"

    periods = analysis.get("periods") or {}
    comparisons = analysis.get("comparisons") or []

    # ----------------- استخراج/تجمیع داده‌ها با ایمنی -----------------
    period_names = []
    overall_avgs = []
    above_10_list = []
    below_10_list = []
    ranges_dict = {}

    try:
        for period_name, stats in (periods or {}).items():
            # متن
            if isinstance(stats, dict) and "message" in stats:
                txt += f"📌 {period_name}: {stats.get('message')}\n\n"
                continue

            # مقادیر امن
            def gv(key, default=0):
                v = (stats or {}).get(key, default)
                try:
                    # برای عددی‌ها
                    if isinstance(default, (int, float)):
                        if v is None:
                            return default
                        v = float(v)
                        if not np.isfinite(v):
                            return default
                        return v
                    return v
                except Exception:
                    return default

            total_students = int(gv("total_students", 0))
            count_with_scores = int(gv("count_with_scores", 0))
            overall_avg = float(gv("overall_avg", 0.0))
            above_10 = int(gv("above_10", 0))
            below_10 = int(gv("below_10", 0))
            max_avg = float(gv("max_avg", 0.0))
            min_avg = float(gv("min_avg", 0.0))
            ranges = (stats or {}).get("ranges") or {}
            subjects = (stats or {}).get("subjects") or {}

            txt += f"📌 دوره: {period_name}\n"
            txt += f"👥 تعداد کل دانش‌آموزان: {total_students}\n"
            txt += f"📝 تعداد با نمره ثبت‌شده: {count_with_scores}\n"
            txt += f"📈 میانگین کل: {overall_avg}\n"
            txt += f"✅ قبولی‌ها (>=10): {above_10}\n"
            txt += f"❌ مردودی‌ها (<10): {below_10}\n"
            txt += f"🔝 بیشترین معدل: {max_avg}\n"
            txt += f"🔻 کمترین معدل: {min_avg}\n"
            txt += f"📊 پراکندگی نمرات:\n"
            txt += "━" * 20
            txt += "\n     بازه| تعداد\n"
            for rng, cnt in (ranges or {}).items():
                try:
                    cnt = int(cnt or 0)
                except Exception:
                    cnt = 0
                txt += f"   • {rng}: {cnt} نفر\n"

            if subjects:
                txt += f"📚 آمار هر درس:\n"
                txt += "━" * 20
                txt += "\n     درس            | تعداد نمرات| میانگین\n"
                for subj, data in (subjects or {}).items():
                    cnt = 0
                    avg = 0.0
                    try:
                        cnt = int((data or {}).get("count", 0) or 0)
                    except Exception:
                        cnt = 0
                    try:
                        avg = float((data or {}).get("avg", 0.0) or 0.0)
                        if not np.isfinite(avg):
                            avg = 0.0
                    except Exception:
                        avg = 0.0
                    txt += f"   • {str(subj).ljust(15)} {str(cnt).ljust(11)}, {str(avg).rjust(7)}\n"
            txt += "\n"

            # برای نمودارها (فقط اگر عدد معتبر)
            period_names.append(str(period_name))
            overall_avgs.append(float(overall_avg))
            above_10_list.append(int(above_10))
            below_10_list.append(int(below_10))

            for rng, cnt in (ranges or {}).items():
                try:
                    cnt = int(cnt or 0)
                except Exception:
                    cnt = 0
                ranges_dict.setdefault(rng, []).append(cnt)

    except Exception as e:
        log.error(f"format text/collect data error: {e}", exc_info=True)

    # ----------------- مقایسه‌های بین‌دوره‌ای (متن) -----------------
    try:
        comps = comparisons or []
        if comps:
            txt += "━" * 20 + "\n"
            txt += "📌 مقایسه دوره‌ها:\n"
            for comp in comps:
                prev_p = comp.get("prev_period")
                curr_p = comp.get("curr_period")
                txt += f"🔸 از «{prev_p}» تا «{curr_p}»:\n"
                if "avg_change" in comp:
                    try:
                        change = float(comp.get("avg_change", 0) or 0)
                        sign = "📈 پیشرفت" if change > 0 else ("📉 افت" if change < 0 else "➖ بدون تغییر")
                        txt += f"   • تغییر میانگین کل: {change} ({sign})\n"
                    except Exception:
                        pass
                if "success_change" in comp:
                    try:
                        ch = float(comp.get("success_change", 0) or 0)
                        sign = "📈 افزایش قبولی" if ch > 0 else ("📉 کاهش قبولی" if ch < 0 else "➖ بدون تغییر")
                        txt += f"   • تغییر تعداد قبولی‌ها: {ch} ({sign})\n"
                    except Exception:
                        pass
                txt += "\n"
    except Exception as e:
        log.error(f"comparisons text build error: {e}", exc_info=True)

    # اگر هیچ دوره‌ای جمع نشده باشد، فقط متن را بده
    if len(period_names) == 0:
        return txt.strip(), None

    # ----------------- نمودارها (با هندل خطا) -----------------
    chart_path = None
    # plt.style.use('seaborn-v0_8-poster')  # یا 'ggplot', 'fivethirtyeight'
    try:
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        axes = axes.flatten()
        try:
            fig.suptitle(fix_farsi(f" تحلیل تصویری چند دوره‌ای مدرسه {name}  {jdatetime.datetime.now().strftime(' %Y/%m/%d')}"), fontsize=18, weight="bold")
        except Exception:
            pass

        # برچسب‌های محور X (راست‌به‌چپ)
        x_labels = [fix_farsi(name) for name in period_names]

        # 1) میانگین کل هر دوره + خط روند (در صورت کفایت داده)
        try:
            if len(overall_avgs) >= 1:
                axes[0].plot(
                    x_labels,
                    overall_avgs,
                    marker="o",
                    linewidth=2,
                    markersize=8,
                    label=fix_farsi("میانگین کل")
                )

                # خط روند فقط اگر >=2 نقطه‌ی معتبر و واریانس وجود داشته باشد
                finite_mask = [np.isfinite(v) for v in overall_avgs]
                if sum(finite_mask) >= 2:
                    xs = np.arange(len(overall_avgs))[finite_mask]
                    ys = np.array(overall_avgs, dtype=float)[finite_mask]
                    if np.ptp(xs) > 0:  # از تقسیم بر صفر جلوگیری
                        try:
                            z = np.polyfit(xs, ys, 1)
                            p = np.poly1d(z)
                            axes[0].plot(x_labels, p(np.arange(len(overall_avgs))), linestyle="--", linewidth=1.5,
                                         label=fix_farsi("روند کلی"))
                        except Exception as e:
                            log.warning(f"trend polyfit skipped: {e}")
                # هایلایت بیشینه/کمینه
                try:
                    max_idx = int(np.nanargmax(overall_avgs))
                    min_idx = int(np.nanargmin(overall_avgs))
                    axes[0].plot(max_idx, overall_avgs[max_idx], marker="*", markersize=12,
                                 label=fix_farsi("بیشترین"))
                    axes[0].plot(min_idx, overall_avgs[min_idx], marker="*", markersize=12,
                                 label=fix_farsi("کمترین"))
                except Exception:
                    pass

                # اعداد روی نقاط
                for i, avg in enumerate(overall_avgs):
                    if not np.isfinite(avg):
                        continue
                    offset = abs(avg) * 0.02 if avg != 0 else 0.2
                    axes[0].text(i, avg + offset, f"{avg:.1f}", ha="center", va="bottom", fontsize=10,
                                 weight="bold")

                axes[0].set_title(fix_farsi(" میانگین کل هر دوره"), fontsize=12, weight="bold")
                axes[0].set_ylabel(fix_farsi("میانگین"))
                axes[0].grid(axis="y", linestyle="--", alpha=0.3)
                axes[0].set_xticks(range(len(x_labels)))
                axes[0].legend()
        except Exception as e:
            log.error(f"panel[0] error: {e}", exc_info=True)

        # 2) درصد قبولی/مردودی (Pie برای هر دوره) — فقط اگر حداقل یک دوره total>0
        import random  # <--- اضافه کردن کتابخانه random

        try:
            totals = [max(int(a) + int(b), 0) for a, b in zip(above_10_list, below_10_list)]
            valid_any = any(t > 0 for t in totals)
            if valid_any:
                max_total_students = max(totals + [1])
                x_positions = np.linspace(0, len(period_names) * 2, len(period_names))

                wedges_for_legend = None
                legend_labels = [fix_farsi("قبولی"), fix_farsi("مردودی")]

                # لیستی از رنگ‌های زیبا برای انتخاب تصادفی قبولی‌ها
                pass_colors = ['#1f77b4', '#2ca02c', '#ff7f0e', '#9467bd', '#8c564b', '#d62728', '#bcbd22', '#17becf',
                               '#e7ba52']
                fail_color = '#d62728'  # رنگ ثابت قرمز برای مردودی‌ها

                for i, (a, b, name, x) in enumerate(zip(above_10_list, below_10_list, period_names, x_positions)):
                    total = int(a) + int(b)
                    if total <= 0:
                        continue

                    radius = 0.5 + 0.3 * (total / max_total_students)
                    sizes = [a / total if total else 0, b / total if total else 0]

                    try:
                        # <<-- تغییر اصلی: انتخاب رنگ تصادفی برای قبولی در هر حلقه -->>
                        current_pass_color = pass_colors[i % len(pass_colors)]
                        current_pie_colors = [current_pass_color, fail_color]

                        wedges, texts, autotexts = axes[1].pie(
                            sizes,
                            labels=None,
                            autopct="%1.0f%%",
                            startangle=90,
                            center=(x, 0),
                            radius=radius,
                            colors=current_pie_colors  # اعمال رنگ‌های جدید
                        )

                        for autotext in autotexts:
                            autotext.set_color('black')

                        if wedges_for_legend is None:
                            wedges_for_legend = wedges
                        axes[1].text(x, -radius - 0.2, fix_farsi(name), ha="center", va="center",
                                     fontsize=10, weight="bold")
                    except Exception as e:
                        log.warning(f"pie for '{name}' skipped: {e}")

                if wedges_for_legend:
                    axes[1].legend(wedges_for_legend, legend_labels, loc="upper right", fontsize=10)

                axes[1].set_title(fix_farsi(" درصد قبولی /  مردودی"), fontsize=12, weight="bold")
                axes[1].axis("equal")
                axes[1].axis("off")
                axes[1].set_ylim(-1.5, 1)
            else:
                axes[1].set_title(fix_farsi("داده‌ای برای درصد قبولی/مردودی موجود نیست"), fontsize=12, weight="bold")
                axes[1].axis("off")
        except Exception as e:
            log.error(f"panel[1] error: {e}", exc_info=True)
        # 3) پراکندگی نمرات
        try:
            # هم‌طول‌کردن سری‌های بازه‌ها با تعداد دوره‌ها
            for rng in list(ranges_dict.keys()):
                counts = ranges_dict[rng]
                if len(counts) < len(period_names):
                    ranges_dict[rng] = counts + [0] * (len(period_names) - len(counts))

            if ranges_dict:
                colors = ["#d62728", "#ff7f0e", "#1f77b4", "#2ca02c", "#9467bd"]  # لیست رنگ دلخواه
                texts_to_adjust = []
                bbox_props = dict(boxstyle="round,pad=0.2", facecolor='white', alpha=0.5, edgecolor='none')

                for idx, (rng, counts) in enumerate(ranges_dict.items()):
                    # رنگ مربوط به این خط را در یک متغیر ذخیره می‌کنیم
                    line_color = colors[idx % len(colors)]

                    y = [int(c or 0) for c in counts]
                    axes[2].plot(x_labels, y, marker="o", linewidth=2, label=fix_farsi(rng),
                                 color=line_color)  # استفاده از رنگ
                    for i, val in enumerate(y):
                        texts_to_adjust.append(
                            axes[2].text(i, val, str(val),
                                         ha="center",
                                         va="center",
                                         fontsize=9,
                                         weight="bold",
                                         color=line_color,
                                         bbox=bbox_props)  # افزودن کادر برای خوانایی بهتر
                        )

                adjust_text(texts_to_adjust,
                            ax=axes[2],
                            arrowprops=dict(arrowstyle='-', color='grey', lw=0.5))

                axes[2].set_title(fix_farsi(" پراکندگی نمرات"), fontsize=12, weight="bold")
                axes[2].legend(fontsize=10, loc="upper left")
                axes[2].grid(axis="y", linestyle="--", alpha=0.3)
                axes[2].grid(axis="x", linestyle=":", alpha=0.2)
            else:
                axes[2].set_title(fix_farsi("پراکندگی در دسترس نیست"), fontsize=12, weight="bold")
                axes[2].axis("off")
        except Exception as e:
            log.error(f"panel[2] error: {e}", exc_info=True)
        # 4) تغییرات بین دوره‌ها
        try:
            comps = comparisons or []
            if comps:
                avg_changes = [float(comp.get("avg_change", 0) or 0) for comp in comps]
                success_changes = [float(comp.get("success_change", 0) or 0) for comp in comps]
                comp_labels = [f"{comp.get('prev_period')}→{comp.get('curr_period')}" for comp in comps]

                x_comp_labels = [fix_farsi(name) for name in comp_labels]
                axes[3].plot(x_comp_labels, avg_changes, marker="o", linewidth=2, label=fix_farsi("تغییر میانگین"))
                axes[3].plot(x_comp_labels, success_changes, marker="s", linewidth=2, label=fix_farsi("تغییر قبولی"))

                # --- مدیریت هوشمند متن‌ها ---
                texts_to_adjust = []
                bbox_props = dict(boxstyle="round,pad=0.2", facecolor='white', alpha=0.8, edgecolor='none')

                for i, (a, s) in enumerate(zip(avg_changes, success_changes)):
                    texts_to_adjust.append(
                        axes[3].text(i, a, f"{a:+.1f}", ha="center", va="center", fontsize=9, bbox=bbox_props)
                    )
                    texts_to_adjust.append(
                        axes[3].text(i, s, f"{s:+.0f}", ha="center", va="center", fontsize=9, bbox=bbox_props)
                    )

                # فراخوانی adjust_text برای جلوگیری از همپوشانی
                adjust_text(texts_to_adjust,
                            ax=axes[3],
                            arrowprops=dict(arrowstyle='-', color='grey', lw=0.5))

                axes[3].set_title(fix_farsi(" تغییرات بین دوره‌ها"), fontsize=12, weight="bold")
                axes[3].set_xticks(range(len(x_comp_labels)))
                axes[3].set_xticklabels(x_comp_labels, rotation=45, ha="right", fontsize=10)
                axes[3].legend(loc="upper right", fontsize=10)
                axes[3].axhline(0, color='grey', linewidth=0.8, linestyle='--')  # خط مبنای صفر
                axes[3].grid(axis="y", linestyle="--", alpha=0.3)
            else:
                axes[3].set_title(fix_farsi("داده‌ای برای مقایسه‌ی دوره‌ها موجود نیست"), fontsize=12, weight="bold")
                axes[3].axis("off")
        except Exception as e:
            log.error(f"panel[3] error: {e}", exc_info=True)

        try:
            plt.tight_layout(rect=[0, 0.03, 1, 0.96])
        except Exception:
            pass

        try:
            tmp_file = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
            plt.savefig(tmp_file.name, bbox_inches="tight", dpi=300)
            chart_path = tmp_file.name
        except Exception as e:
            log.error(f"savefig error: {e}", exc_info=True)
            chart_path = None
        finally:
            try:
                plt.close()
            except Exception:
                pass

    except Exception as e:
        # اگر کل بخش نمودار خطا داد، فقط متن را برگردان
        logging.getLogger(__name__).error(f"figure build error: {e}", exc_info=True)
        chart_path = None
        try:
            plt.close()
        except Exception:
            pass

    return txt.strip(), chart_path
